
import UIKit

class doctorlistviewcontroller: UIViewController,UISearchBarDelegate,UISearchTextFieldDelegate{
   
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var listTable: UITableView!
    var doctors: doctorlist?
    var Searchbar:docsearch?
    var searchOption = false
    var doctorid: String = ""
    let refreshControl = UIRefreshControl()
    let loaderView = loader()
    @IBOutlet weak var searchbar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        listTable.dataSource = self
        listTable.delegate = self
        listTable.register(UINib(nibName: "dcotorlisttvc", bundle: nil), forCellReuseIdentifier: "dcotorlisttvc")
        searchbar.delegate = self
        
        view.addSubview(loaderView)
                loaderView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    loaderView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                    loaderView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
                ])

        
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        listTable.addSubview(refreshControl)
   
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchData()
    }
    @objc func refresh(_ sender: AnyObject) {
       // Code to refresh table view
        searchOption = false
        fetchData()
    }
    func searchApi(userId: String) {
        let formData = [
            "user_id": userId,
            "search" : userId
        ]

        searchOption = true
        //http://192.168.210.118/medproject/search.php?search=M
        let url = "\(ServiceAPI.dsearchUrl)?search=\(userId)"
        APIHandler.shared.getAPIValues(type: docsearch.self, apiUrl: url, method: "GET") { [weak self] result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
//                        self?.Searchbar = UntangledMind.Searchbar(status: true, search: response)
                        self?.Searchbar = response
                        self?.listTable.reloadData()
                        print("Search API Success:", response)
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert", message: "The Patient Does not Exist", preferredStyle: .alert)
                        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(cancelAction)
                        self?.present(alertController, animated: false, completion: nil)
                        print("Search API Error:", error)
                    }
                }
            }
        }

      
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func fetchData() {
        showLoader()
        APIHandler().getAPIValues(type: doctorlist.self, apiUrl: ServiceAPI.doctorslistUrl, method: "GET") { [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        // Reverse the order of the data array
                        self?.doctors = doctorlist(status: data.status, data: data.data?.reversed())

                        self?.listTable.reloadData()
                        self?.refreshControl.endRefreshing()
                        self?.hideLoader()
                    }
                case .failure(let error):
                    print("API Request Error: \(error)")
                    self?.hideLoader()
                    // Handle the failure case as needed
                }
            }
        }
    func showLoader() {
           loaderView.startAnimating()
       }
       
       func hideLoader() {
           loaderView.stopAnimating()
       }
   
}
extension doctorlistviewcontroller: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchOption {
       
            return Searchbar?.data.count ?? 0
        } else {
            return doctors?.data?.count ?? 0
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "dcotorlisttvc", for: indexPath) as! dcotorlisttvc
        if searchOption {

            cell.nameLabel.text = Searchbar?.data[indexPath.row].name
            cell.useridLabel.text = Searchbar?.data[indexPath.row].userID
            cell.ageLabel.text = Searchbar?.data[indexPath.row].age

            if let imgurlStr = Searchbar?.data[indexPath.row].doctorimage,
                           let imgUrl = URL(string: ServiceAPI.baseUrl + imgurlStr) {
                            DispatchQueue.global().async {
                                URLSession.shared.dataTask(with: imgUrl) { (data, response, error) in
                                    guard let data = data, error == nil else {
                                        print("Failed to download image:", error?.localizedDescription ?? "Unknown error")
                                        DispatchQueue.main.async {
                                            cell.docimageLabel.image = UIImage(named: "Rectangle 9")
                                        }
                                        return
                                    }

                                    DispatchQueue.main.async {
                                        cell.docimageLabel.image = UIImage(data: data)
                                    }
                                }.resume()
                            }
                        }
        } else {
            if let dlist = doctors, let dict = dlist.data?[indexPath.row] {
                cell.nameLabel.text = dict.name
                cell.ageLabel.text = dict.age
                cell.useridLabel.text = dlist.data?[indexPath.row].userID
                UserDefaults.standard.setValue(dlist.data?[indexPath.row].userID, forKey: "SelecteduserID")

                if let imgurlStr = dict.doctorimage,
                   let imgUrl = URL(string: ServiceAPI.baseUrl + imgurlStr) {
                    DispatchQueue.global().async {
                        URLSession.shared.dataTask(with: imgUrl) { (data, response, error) in
                            guard let data = data, error == nil else {
                                // Handle the error, if any
                                print("Failed to download image:", error?.localizedDescription ?? "Unknown error")
                                DispatchQueue.main.async {
                                    cell.docimageLabel.image = UIImage(named: "Rectangle 9")
                                }
                                return
                            }
                            
                            DispatchQueue.main.async {
                                // Update the UI on the main thread
                                cell.docimageLabel.image = UIImage(data: data)
                            }
                        }.resume()
                    }
                }


            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "doctordetailsvc") as! doctordetailsvc

            if searchOption {
                if let id = Searchbar?.data[indexPath.row].userID {
                    DoctorManager.shared.doctorID = id
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                if let ids = doctors?.data?[indexPath.row].userID {
                    DoctorManager.shared.doctorID = ids
                    print("Selected patient ID-->", ids)
                    print(DoctorManager.shared.doctorID!)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }

 
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
}
extension doctorlistviewcontroller: UITextFieldDelegate {


    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            
            searchOption = false
            listTable.reloadData()
        } else {
            // Perform search
            searchApi(userId: searchText)
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("Return key pressed")
        textField.resignFirstResponder()
        return true
    }
}
