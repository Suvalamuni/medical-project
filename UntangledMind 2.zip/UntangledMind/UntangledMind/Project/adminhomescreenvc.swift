//
//  adminhomescreenvc.swift
//  UntangledMind
//
//  Created by Amar on 19/03/24.
//

import UIKit

class adminhomescreenvc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func adddoctorbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "adddoctorvc")
        as! adddoctorvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func doctorlistbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "doctorlistviewcontroller")
            as! doctorlistviewcontroller
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    @IBAction func addctbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "caretaker_details")
            as! caretaker_details
            self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func ctlistbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "caretakerslistvc")
            as! caretakerslistvc
            self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    @IBAction func edittopicvc(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "d_topiclist")
            as! d_topiclist
            self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    @IBAction func profile(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "adminprofilevc")
            as! adminprofilevc
            self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func addtopicsbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "add_topicsvc")
            as! add_topicsvc
            self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
}
    

