
import UIKit

class adminloginvc: UIViewController {



    @IBOutlet weak var onview: UIView!
    
    @IBOutlet weak var user_id: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var loginraduis: UIButton!
    var apiURL = String()
    var logInDetails: admin!
    let loaderView = loader()
    
    
    let defaults = UserDefaults.standard

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        onview.layer.cornerRadius=5
        onview.clipsToBounds=true
        loginraduis.layer.cornerRadius=5
        loginraduis.clipsToBounds=true
        password.isSecureTextEntry = true
        onview.addSubview(loaderView)
                loaderView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    loaderView.centerXAnchor.constraint(equalTo: onview.centerXAnchor),
                    loaderView.centerYAnchor.constraint(equalTo: onview.centerYAnchor)
                ])
    }
    
    
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    

    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
    }
    
    
    @IBAction func onlogin(_ sender: Any) {
        showLoader()
        apiURL = "\(ServiceAPI.adminloginUrl)?user_id=\(user_id.text ?? "")&password=\(password.text ?? "")"
        
        if user_id.text == "" && password.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
            hideLoader()
        } else {
            getLoginAPI()
        }
    }

    func getLoginAPI() {
        let formData = [
            "user_id": user_id.text ?? "",
            "password": password.text ?? ""
        ]
        APIHandler().postAPIValues(type: admin.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.logInDetails = data
           
                DispatchQueue.main.async {
                                    if let firstDatum = self.logInDetails.data.first {
                                        if self.user_id.text != firstDatum.userID && self.password.text != firstDatum.password {
                                            let alert = UIAlertController(title: "OOPS", message: "Incorrect User ID & password", preferredStyle: .alert)
                                            alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                                                print("Incorrect User ID & password")
                                            })
                                            self.present(alert, animated: true)
                                        } else {
                                            DoctorManager.shared.adminID = firstDatum.userID
                                            
                                            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                                            let vc = storyboard.instantiateViewController(withIdentifier: "adminhomescreenvc") as! adminhomescreenvc
                                            self.navigationController?.pushViewController(vc, animated: true)
                                        }
                                    } else {
                                        // Handle the case where logInDetails.data is empty
                                        let alert = UIAlertController(title: "Alert", message: "Data is empty", preferredStyle: .alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                        self.present(alert, animated: true)
                                    }
                                    self.hideLoader()
                                }
                            case .failure(let error):
                                print(error.localizedDescription)
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: .alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                    self.present(alert, animated: true)
                                    self.hideLoader()
                                }
                            }
                        }
                    }
    func showLoader() {
            loaderView.startAnimating()
        }
        
        func hideLoader() {
            loaderView.stopAnimating()
        }
}
