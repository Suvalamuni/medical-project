// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Caretaker_login_model: Codable {
    let status: Bool
    let message: String
    let data: [Caretaker]
}

// MARK: - Datum
struct Caretaker: Codable {
   // let userID, password: String
    let id, userID, password, name: String
    let phoneNo, age, gender, pName: String
    let pAge, pGender, diagnosis, relationship: String
    let caretakerImage: String

    enum CodingKeys: String, CodingKey {
//        case userID = "user_id"
//        case password
        case id
        case userID = "user_id"
        case password
        case name = "Name"
        case phoneNo = "phone_no"
        case age = "Age"
        case gender
        case pName = "p_Name"
        case pAge = "p_Age"
        case pGender = "p_Gender"
        case diagnosis = "Diagnosis"
        case relationship = "Relationship"
        case caretakerImage = "Caretaker_image"
    }
}





