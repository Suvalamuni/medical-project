

import Foundation

// MARK: - Welcome
struct admin: Codable {
    let status: Bool
    let message: String
    let data: [adminlogin]
}

// MARK: - Datum
struct adminlogin: Codable {
    let userID, name, emailID, password: String
    let phoneNo, designation, institution: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case emailID = "email_id"
        case password
        case phoneNo = "phone_no"
        case designation, institution
    }
}
