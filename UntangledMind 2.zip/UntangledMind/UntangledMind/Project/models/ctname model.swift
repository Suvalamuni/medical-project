// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let caretakernamemodel = try? JSONDecoder().decode(Caretakernamemodel.self, from: jsonData)

import Foundation

// MARK: - Caretakernamemodel
struct Caretakernamemodel: Codable {
    let status: Bool
    let data: [name]
}

// MARK: - Datum
struct name: Codable {
    let name: String

    enum CodingKeys: String, CodingKey {
        case name = "Name"
    }
}
