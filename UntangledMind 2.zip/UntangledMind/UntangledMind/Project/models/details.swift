
import Foundation

// MARK: - Welcome

struct details: Codable {
    let userID, name, diagnosis, caretakerImage: String
    let age: Int
    let gender, phoneNo, relationship, pName: String
    let pAge: Int
    let pGender: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case diagnosis = "Diagnosis"
        case caretakerImage = "Caretaker_image"
        case age = "Age"
        case gender
        case phoneNo = "phone_no"
        case relationship = "Relationship"
        case pName = "p_Name"
        case pAge = "p_Age"
        case pGender = "p_Gender"
    }
}

