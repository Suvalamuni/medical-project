
import Foundation
struct AddSuggestions: Codable {
    let success: Bool
    let message: String
}
