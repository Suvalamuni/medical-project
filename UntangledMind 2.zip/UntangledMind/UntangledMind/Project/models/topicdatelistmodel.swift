// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let doctorName = try? JSONDecoder().decode(DoctorName.self, from: jsonData)

import Foundation

// MARK: - DoctorName
struct topicdatelist: Codable {
    let success: Bool
    let data: [topicdate]
}

// MARK: - Datum
struct topicdate: Codable {
    let subtopicName, userID, date: String

    enum CodingKeys: String, CodingKey {
        case subtopicName = "subtopic_name"
        case userID = "user_id"
        case date
    }
}
