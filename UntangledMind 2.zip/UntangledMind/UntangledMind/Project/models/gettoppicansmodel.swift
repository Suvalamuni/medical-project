// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let getTopicans = try? JSONDecoder().decode(GetTopicans.self, from: jsonData)

import Foundation

// MARK: - GetTopicans
struct GetTopicans: Codable {
    let status: Bool
    let data: [topicanswers]
}

// MARK: - Datum
struct topicanswers: Codable {
    let subtopicName, date, userID: String
    let questionID: Int
    let question, answer: String

    enum CodingKeys: String, CodingKey {
        case subtopicName = "subtopic_name"
        case date
        case userID = "user_id"
        case questionID = "question_id"
        case question, answer
    }
}
