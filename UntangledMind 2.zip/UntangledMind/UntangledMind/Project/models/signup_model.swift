//
//  signup_model.swift
//  hi
//
//  Created by k. Dharani on 28/11/23.
//

import Foundation

// MARK: - Welcome
struct signup_model : Codable {
    let status , message : String
}
struct SentQuestion : Codable {
    let message :String
    let status:Bool
    
}
