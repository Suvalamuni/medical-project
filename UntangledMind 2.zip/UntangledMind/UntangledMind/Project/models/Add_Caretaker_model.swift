//
//  Add_Caretaker_model.swift
//  hi
//
//  Created by k. Dharani on 13/12/23.
//

import Foundation

// MARK: - Welcome
struct ADD_CareTaker: Codable {
    let status, message: String
}
