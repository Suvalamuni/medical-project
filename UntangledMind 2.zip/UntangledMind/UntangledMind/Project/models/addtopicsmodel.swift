

import Foundation

struct Addtopics: Codable {
    let success: Bool
    let message: String
}
