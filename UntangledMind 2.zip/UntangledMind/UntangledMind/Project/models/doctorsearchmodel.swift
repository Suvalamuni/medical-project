

import Foundation

// MARK: - Welcome
struct docsearch: Codable {
    let status: Bool
    let data: [doctsearch]
}

// MARK: - Datum
struct doctsearch: Codable {
    let userID, name, age, doctorimage: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case age = "Age"
        case doctorimage
    }
}
