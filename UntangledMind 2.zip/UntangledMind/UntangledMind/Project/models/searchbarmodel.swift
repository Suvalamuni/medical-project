

import Foundation


struct SearchbarModel: Codable {
    let status: Bool
    let data: [Search]
}

// MARK: - Search
struct Search: Codable {
    let userID, name, diagnosis: String
    let caretakerImage: String


    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case diagnosis = "Diagnosis"
        case caretakerImage = "Caretaker_image"
    }
}

