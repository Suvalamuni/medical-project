// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let topics = try? JSONDecoder().decode(Topics.self, from: jsonData)

import Foundation

// MARK: - Topics
struct Topics: Codable {
    let success: Bool
    let data: [topic]
}

// MARK: - Datum
struct topic: Codable {
    let topicID, topicName: String
        //let image: String

    enum CodingKeys: String, CodingKey {
        case topicID = "topic_id"
                case topicName = "topic_name"
                //case image
    }
}
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let topics = try? JSONDecoder().decode(Topics.self, from: jsonData)

