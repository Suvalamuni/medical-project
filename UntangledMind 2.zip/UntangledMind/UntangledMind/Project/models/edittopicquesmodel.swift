

import Foundation

// MARK: - EditQuestions
struct EditQuestions: Codable {
    let status: Bool
    let message: String
}
