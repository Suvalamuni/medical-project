// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let getVideo = try? JSONDecoder().decode(GetVideo.self, from: jsonData)

import Foundation

// MARK: - GetVideo

struct GetVideo: Codable {
    let success: Bool
    let videoURL: String
    let description: String

    enum CodingKeys: String, CodingKey {
        case success
        case videoURL = "video_url"
        case description
    }
}
