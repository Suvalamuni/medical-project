// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let getans = try? JSONDecoder().decode(Getans.self, from: jsonData)

import Foundation

// MARK: - Getans
struct Getans: Codable {
    let status: Bool
    let data: [get_ans]
}

// MARK: - Datum
struct get_ans: Codable {
    let userID: Int
//    let userID: String
        let date: String
        let questionID: Int
        let userAnswer, questionText: String

        enum CodingKeys: String, CodingKey {
            case userID = "user_id"
            case date
            case questionID = "question_id"
            case userAnswer = "user_answer"
            case questionText = "question_text"
        }
    }
