// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let getmotivationimage = try? JSONDecoder().decode(Getmotivationimage.self, from: jsonData)

import Foundation


struct Getmotivationimage: Codable {
    let status: Bool
    let data: [mtimage]
}

// MARK: - Datum
struct mtimage: Codable {
    let userID: Int
//    let userID: String
    let image1, image2, image3, image4: String
    let image5, image6: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case image1, image2, image3, image4, image5, image6
    }
}
