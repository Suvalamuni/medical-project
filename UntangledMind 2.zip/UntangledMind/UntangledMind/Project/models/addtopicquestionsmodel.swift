
import Foundation

// MARK: - Addtopicquestions
struct Addtopicquestions: Codable {
    let success: Bool
    let message: String
}
struct Addtopicquestionsrequest: Codable {
    let subtopicID, subtopicName: String
    let questions: [Question]

    enum CodingKeys: String, CodingKey {
        case subtopicID = "subtopic_id"
        case subtopicName = "subtopic_name"
        case questions
    }
}

struct Question: Codable {
    let questionID, question, optionA, optionB: String
    let optionC, optionD: String

    enum CodingKeys: String, CodingKey {
        case questionID = "question_id"
        case question
        case optionA = "option_a"
        case optionB = "option_b"
        case optionC = "option_c"
        case optionD = "option_d"
    }
}
