

import Foundation

// MARK: - Welcome
struct adminprofile: Codable {
    let status: Bool
    let data: [adminprof]
}

// MARK: - Datum
struct adminprof: Codable {
    let userID, name, emailID, phoneNo: String
    let institution, designation: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case emailID = "email_id"
        case phoneNo = "phone_no"
        case institution, designation
    }
}
