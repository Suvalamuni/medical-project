// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let doctorProfile = try? JSONDecoder().decode(DoctorProfile.self, from: jsonData)

import Foundation

struct DoctorProfile: Codable {
    let status: Bool
    let data: [Doc_profile]
}

// MARK: - Datum
struct Doc_profile: Codable {
    let userID, name, password, age: String
    let emailID, phoneNo, institution, designation: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case password
        case age = "Age"
        case emailID = "email_id"
        case phoneNo = "phone_no"
        case institution, designation
    }
}

