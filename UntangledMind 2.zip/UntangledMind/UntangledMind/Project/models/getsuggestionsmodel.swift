// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let getSuggestions = try? JSONDecoder().decode(GetSuggestions.self, from: jsonData)

import Foundation

// MARK: - GetSuggestions
struct GetSuggestions: Codable {
    let status: Bool
    let data: [suggestin]
}

// MARK: - Datum
struct suggestin: Codable {
    let suggestion: String
    let userID: Int
//    let userID: String
    let date: String

    enum CodingKeys: String, CodingKey {
        case suggestion
        case userID = "user_id"
        case date
    }
}
