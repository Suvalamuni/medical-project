// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

struct Doctor_login: Codable {
    let status: Bool
    let message: String
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable {
    let userID, name, emailID, password: String
        let phoneNo, designation, institution: String

        enum CodingKeys: String, CodingKey {
            case userID = "user_id"
            case name = "Name"
            case emailID = "email_id"
            case password
            case phoneNo = "phone_no"
            case designation, institution
        }
    }
