// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let qDate = try? JSONDecoder().decode(QDate.self, from: jsonData)

import Foundation

struct QDate: Codable {
    let status: Bool
    let data: [quesdate]
}

// MARK: - Datum
struct quesdate: Codable {
//    let userID: Int
////    let userID: String
//    let date : String
    let userID, date: String
    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case date
    }
}

//import Foundation
//
//// MARK: - Welcome
//struct Welcome: Codable {
//    let status: Bool
//    let data: [Datum]
//}
//
//// MARK: - Datum
//struct Datum: Codable {
//    let userID, date: String
//
//    enum CodingKeys: String, CodingKey {
//        case userID = "user_id"
//        case date
//    }
//}
