// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let patientProfile = try? JSONDecoder().decode(PatientProfile.self, from: jsonData)

import Foundation

// MARK: - PatientProfile
struct CaretakerProfile: Codable {
    let status: Bool
    let data: [pprofile]
}

// MARK: - Datum
struct pprofile: Codable {
    let userID, name, phoneNo, pName: String
    let relationship, diagnosis: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case phoneNo = "phone_no"
        case pName = "p_Name"
        case relationship = "Relationship"
        case diagnosis = "Diagnosis"
    }
}
