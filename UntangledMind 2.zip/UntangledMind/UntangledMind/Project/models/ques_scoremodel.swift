// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let qscore = try? JSONDecoder().decode(Qscore.self, from: jsonData)

import Foundation

// MARK: - Qscore
struct Qscore: Codable {
    let status: Bool
    let data: [q_score]
}

// MARK: - Datum
struct q_score: Codable {
//    let userID: Int
    let userID: String
    let date: String
    let totalScore: Int
    let a, b, c, d: Int
    let e: Int

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case date
        case totalScore = "total_score"
        case a = "A"
        case b = "B"
        case c = "C"
        case d = "D"
        case e = "E"
    }
}

