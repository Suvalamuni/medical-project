import Foundation

// MARK: - DoctorName
struct DoctorName: Codable {
    let status: Bool
    let data: [docname]
}

// MARK: - Datum
struct docname: Codable {
    let name: String

    enum CodingKeys: String, CodingKey {
        case name = "Name" // Change this line to map the correct key
    }
}
