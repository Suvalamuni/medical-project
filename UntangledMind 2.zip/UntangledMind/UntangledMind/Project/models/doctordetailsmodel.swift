
import Foundation

// MARK: - Welcome
struct docdetails: Codable {
    let userID, name, password, emailID: String
    let age, gender, phoneNo, designation: String
    let institution, doctorimage: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case password
        case emailID = "email_id"
        case age = "Age"
        case gender = "Gender"
        case phoneNo = "phone_no"
        case designation, institution, doctorimage
    }
}
