// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let postAns = try? JSONDecoder().decode(PostAns.self, from: jsonData)

import Foundation

// MARK: - PostAns
//struct PostAns: Codable {
//    let status, message: String
//    let totalScore: Int
//
//    enum CodingKeys: String, CodingKey {
//        case status, message
//        case totalScore = "total_score"
//    }
//}

struct PostAns: Codable {
    let message: String
    let status: Bool
}




struct questionarieans: Codable {
    let userID: Int
//    let userID: String
    let score: [answer]

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case score = "Score"
    }
}

// MARK: - Score
struct answer: Codable {
    let questionids: Int
    let answer: String

    enum CodingKeys: String, CodingKey {
        case questionids = "Questionids"
        case answer = "Answer"
    }
}
