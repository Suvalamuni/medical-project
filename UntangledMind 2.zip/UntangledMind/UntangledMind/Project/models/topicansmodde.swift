// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let topicans = try? JSONDecoder().decode(Topicans.self, from: jsonData)

import Foundation

// MARK: - Topicans
struct Topicans: Codable {
    let status, message: String
    let totalScore: Int

    enum CodingKeys: String, CodingKey {
        case status, message
        case totalScore = "total_score"
    }
}
