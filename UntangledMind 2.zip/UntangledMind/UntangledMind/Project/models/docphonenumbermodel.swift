

import Foundation

// MARK: - Phonenumbermodel
struct Phonenumbermodel: Codable {
    let status: Bool
    let data: [phonenum]
}

// MARK: - Datum
struct phonenum: Codable {
    let phoneNo: String

    enum CodingKeys: String, CodingKey {
        case phoneNo = "phone_no"
    }
}
