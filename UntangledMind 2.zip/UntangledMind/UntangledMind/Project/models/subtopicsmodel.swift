// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let subtopics = try? JSONDecoder().decode(Subtopics.self, from: jsonData)

import Foundation

// MARK: - Subtopics
struct Subtopics: Codable {
    let status: Bool
    let data: [SubtopicData]
}


struct SubtopicData: Codable {
    let topicName: String
    let subtopicId: String
    let subtopicName: String

    // CodingKeys enumeration to handle the snake_case to camelCase conversion
    enum CodingKeys: String, CodingKey {
        case topicName = "topic_name"
        case subtopicId = "subtopic_id"
        case subtopicName = "subtopic_name"
    }
}
