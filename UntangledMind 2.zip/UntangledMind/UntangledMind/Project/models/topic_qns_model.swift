// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let posttopicqns = try? JSONDecoder().decode(Posttopicqns.self, from: jsonData)

import Foundation

// MARK: - Posttopicqns
struct gettopicqns: Codable {
    let status: Bool
    let data: [topicqns]
}

// MARK: - Datum
struct topicqns: Codable {
    let questionID: Int
    let question, optionA, optionB, optionC: String
    let optionD: String

    enum CodingKeys: String, CodingKey {
        case questionID = "question_id"
        case question
        case optionA = "option_a"
        case optionB = "option_b"
        case optionC = "option_c"
        case optionD = "option_d"
    }
}


    
