import Foundation

struct Passwordmodel: Codable {
    let status: Bool
    let data: [password]
}

struct password: Codable {
    let password: String
}
