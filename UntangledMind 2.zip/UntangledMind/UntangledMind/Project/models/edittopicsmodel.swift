import Foundation

// MARK: - Subtopics
struct edittopics: Codable {
    let status: Bool
    let message: String
}
