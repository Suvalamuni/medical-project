

import Foundation

struct EditVideo: Codable {
    let status: Bool
    let message: String
}
