
import Foundation

// MARK: - Welcome
struct adddoctor: Codable {
    let status, message: String
}
