import Foundation

// MARK: - Welcome
struct ct_list: Codable {
    let status: Bool
    let data: [caretaker_info]?

   
}

// MARK: - Caretaker
struct caretaker_info: Codable {
    let userID, name, diagnosis, caretakerImage: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name = "Name"
        case diagnosis = "Diagnosis"
        case caretakerImage = "Caretaker_image"
    }
}
