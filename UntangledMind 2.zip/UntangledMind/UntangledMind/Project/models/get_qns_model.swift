
import Foundation

// MARK: - GetQuestions
struct GetQuestions: Codable {
    let status: Bool
    let data: [GetSubQuestions]?
}

// MARK: - Datum
struct GetSubQuestions: Codable {
    let questionID: Int
    let questionText: String
    let options: [String]

    enum CodingKeys: String, CodingKey {
        case questionID = "question_id"
        case questionText = "question_text"
        case options
    }
}

class GetSubQuestionsData: Codable {
    let questionID: Int?
    var selectedAnsTag: Int?
    let questionText: String?
    let options: [String]?
    
    init(questionID: Int?, selectedAnsTag: Int?, questionText: String?, options: [String]?) {
        self.questionID = questionID
        self.selectedAnsTag = selectedAnsTag
        self.questionText = questionText
        self.options = options
    }
}
