
import UIKit
import MobileCoreServices

class add_topicsvc: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    @IBOutlet weak var topicid: UITextField!
    @IBOutlet weak var topicnamelbl: UITextField!
    @IBOutlet weak var subtopicidlbl: UITextField!
    
    @IBOutlet weak var subtopicnamelbl: UITextField!
    @IBOutlet weak var choosefilebtn: UIButton!
    @IBOutlet weak var descriptionlbl: UITextView!
    
    @IBOutlet weak var videoUploadedStauslbl: UILabel!
    
    
    var selectedImages: [UIImage] = []
    var body = Data()
    var selectedVideoURL: URL?
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
    }
    
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func choosevideo(_ sender: Any) {
        presentImagePicker()
    }
    @IBAction func Next(_ sender: Any) {
        //        navigationController?.popViewController(animated: true)
        if topicid.text == "" ||  topicnamelbl.text == "" || subtopicnamelbl.text == ""  || descriptionlbl.text == ""  {
            print("All fields are required.")
            
        } else {
            
            ADDTOPIC()
        }
    }
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Media", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Choose Video", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        imagePicker.mediaTypes = [kUTTypeMovie as String] // Set media type to video
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
            selectedVideoURL = videoURL
            videoUploadedStauslbl.text = "Video Uploaded"
            
        } else {
            videoUploadedStauslbl.text = "Upload Video"
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    func ADDTOPIC() {
        guard !topicid.text!.isEmpty, !topicnamelbl.text!.isEmpty, !subtopicnamelbl.text!.isEmpty, !descriptionlbl.text!.isEmpty, let videoURL = selectedVideoURL else {
            print("All fields are mandatory.")
            return
        }
        
        let apiURL = ServiceAPI.addtopicUrl
        print("API URL:", apiURL)
        
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        
        let formData: [String: String] = [
            "topic_id": topicid.text ?? "",
            "topic_name": topicnamelbl.text ?? "",
            "subtopic_id": subtopicidlbl.text ?? "",
            "subtopic_name": subtopicnamelbl.text ?? "",
            "description": descriptionlbl.text ?? "",
        ]
        
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        
        // Append video data
        let videoData = try! Data(contentsOf: videoURL)
        body.append(contentsOf: "--\(boundary)\r\n".utf8)
        body.append(contentsOf: "Content-Disposition: form-data; name=\"video\"; filename=\"\(UUID().uuidString).mov\"\r\n".utf8)
        body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
        body.append(contentsOf: videoData)
        body.append(contentsOf: "\r\n".utf8)
        
        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: "Failed to add data. Please try again later.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                if (200...299).contains(httpResponse.statusCode) {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Success", message: "Data added successfully.", preferredStyle: .alert)
                        let okAction = UIAlertAction(title: "OK", style: .default) { [self] _ in
                            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                    if let addTopicQuestionsVC = storyboard.instantiateViewController(withIdentifier: "addtopicquestionsvc") as? addtopicquestionsvc {
                                        addTopicQuestionsVC.subtopicId = self.subtopicidlbl.text ?? ""
                                        addTopicQuestionsVC.subtopicName = subtopicnamelbl.text ?? ""
                                        self.navigationController?.pushViewController(addTopicQuestionsVC, animated: true)
                                    }
                        }
                        alert.addAction(okAction)
                        self.present(alert, animated: true, completion: nil)
                    }                } else {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Error", message: "Failed to add data. Please try again later.", preferredStyle: .alert)
                            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alert.addAction(okAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        
        task.resume()
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

