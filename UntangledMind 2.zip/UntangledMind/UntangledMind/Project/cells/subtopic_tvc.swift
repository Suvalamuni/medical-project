//
//  subtopic_tvc.swift
//  UntangledMind
//
//  Created by k. Dharani on 29/01/24.
//

import UIKit

class subtopic_tvc: UITableViewCell {

    @IBOutlet weak var subtopic_id: UILabel!
    @IBOutlet weak var sb_name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
