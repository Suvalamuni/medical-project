//
//  TopiCansTVC.swift
//  UntangledMind
//
//  Created by k. Dharani on 05/02/24.
//

import UIKit

class TopiCansTVC: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
