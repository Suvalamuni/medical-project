//
//  topicans_TVC.swift
//  UntangledMind
//
//  Created by k. Dharani on 02/02/24.
//

import UIKit

class topicans_TVC: UITableViewCell {
    @IBOutlet weak var question: UILabel!
    @IBOutlet weak var answer: UILabel!
    @IBOutlet weak var ques_id: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
