//
//  CrackerListCell.swift
//  hi
//
//  Created by k. Dharani on 16/11/23.
//

import UIKit

class CrackerListCell: UITableViewCell {
    
    @IBOutlet weak var Profile_Image: UIImageView!
    @IBOutlet weak var user_id: UILabel!
    
    @IBOutlet weak var Name: UILabel!
    
    
    @IBOutlet weak var Diagnosis: UILabel!
    
    
    
    

    
    
    override func layoutSubviews() {
         super.layoutSubviews()
         
     let margin = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
     contentView.frame = contentView.frame.inset(by: margin)
     contentView.layer.cornerRadius = 20
     }
    
    
}
        
 
