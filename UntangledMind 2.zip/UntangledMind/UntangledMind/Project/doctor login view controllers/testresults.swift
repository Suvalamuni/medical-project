import UIKit

class testresults: UIViewController, UITableViewDelegate, UITableViewDataSource{
    var topicdate_list: topicdatelist?
    var user_id = String()
    @IBOutlet weak var table: UITableView!
    var noDataLabel: UILabel?

    override func viewDidLoad() {
        super.viewDidLoad()
        user_id = DoctorManager.shared.caretakerID!
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "testresultTV", bundle: nil), forCellReuseIdentifier: "testresultTV")
        fetchData()
    }
    
    func fetchData() {
        let apiUrl = "\(ServiceAPI.topicdate_listUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
        print(apiUrl)
        APIHandler().getAPIValues(type: topicdatelist.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.topicdate_list = data
                    self?.table.reloadData()
                    if data.data.isEmpty {
                        self?.showNoDataLabel()
                    } else {
                        self?.hideNoDataLabel()
                    }
                }
            case .failure(let error):
                print("API Request Error: \(error)")
                DispatchQueue.main.async {
                    self?.showNoDataLabel()
                }
            }
        }
    }
   
    func showNoDataLabel() {
        if noDataLabel == nil {
            noDataLabel = UILabel(frame: CGRect(x: 0, y: 0, width: table.bounds.size.width, height: table.bounds.size.height))
            noDataLabel?.text = "No data found"
            noDataLabel?.textAlignment = .center
            noDataLabel?.sizeToFit()
            table.backgroundView = noDataLabel
        }
    }
    
    func hideNoDataLabel() {
        noDataLabel?.removeFromSuperview()
        noDataLabel = nil
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topicdate_list?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "testresultTV", for: indexPath) as! testresultTV
        
        let topicDate = topicdate_list?.data[indexPath.row]
        cell.datelbl.text = topicDate?.date
        cell.topicname.text = topicDate?.subtopicName
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "topicansview") as! topicansview
        vc.selectedsubtopic = topicdate_list?.data[indexPath.row].subtopicName ?? ""
        vc.selectedDate = topicdate_list?.data[indexPath.row].date ?? ""
        vc.useridStr = user_id
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)

        }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
}
