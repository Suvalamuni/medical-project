import UIKit

class MotivationImagesViewController: UIViewController {
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var img5: UIImageView!
    @IBOutlet weak var img6: UIImageView!
    
    var images: Getmotivationimage?
    var userId: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let doctorID = DoctorManager.shared.doctorID {
            print("Doctor ID: \(doctorID)")
        } else {
            print("Doctor ID is not available.")
        }
        
        getDetails()
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func getDetails() {
        guard let userIdEncoded = userId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("User ID is nil")
            return
        }
        
        let apiUrl = ServiceAPI.getmotivationimagesUrl
        
        APIHandler().getAPIValues(type: Getmotivationimage.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let getMotivationImage):
                DispatchQueue.main.async {
                    if let firstImage = getMotivationImage.data.first {
                        self?.setImage(imageView: self?.img1, imageName: firstImage.image1)
                        self?.setImage(imageView: self?.img2, imageName: firstImage.image2)
                        self?.setImage(imageView: self?.img3, imageName: firstImage.image3)
                        self?.setImage(imageView: self?.img4, imageName: firstImage.image4)
                        self?.setImage(imageView: self?.img5, imageName: firstImage.image5)
                        self?.setImage(imageView: self?.img6, imageName: firstImage.image6)
                    }
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    
    func setImage(imageView: UIImageView?, imageName: String) {
        if let imageView = imageView, let image = UIImage(named: imageName) {
            imageView.image = image
        }
    }
}
