//
//  activitiesvc.swift
//  hi
//
//  Created by k. Dharani on 22/11/23.
//

import UIKit

class activitiesvc: UIViewController {
    
    
    var useridStr = String()
    
    @IBOutlet weak var dailyques: UIButton!
    @IBOutlet weak var tests: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        useridStr = DoctorManager.shared.caretakerID!
//        self.useridStr = UserDefaults.standard.string(forKey: "SelecteduserID") ?? ""
        print(useridStr, "--hi-->")
        
        // Do any additional setup after loading the view.
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func ontests(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "testresults")
        as! testresults
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func ondaily(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "questionaries_date")
        as! questionaries_date
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
    }
}
