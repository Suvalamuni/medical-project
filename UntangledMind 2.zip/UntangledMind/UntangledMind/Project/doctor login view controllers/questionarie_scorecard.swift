import UIKit

class questionarie_scorecard: UIViewController, UITextViewDelegate {
    var userId: String = ""
    var quesscore: Qscore?
    var dateStr = String()
    var selectedDate: String = ""
    
    @IBOutlet weak var suggestionlbl: UITextView!
    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var score_card: UIView!
    @IBOutlet weak var everyday: UILabel!
    @IBOutlet weak var mostdays: UILabel!
    @IBOutlet weak var somedays: UILabel!
    @IBOutlet weak var never: UILabel!
    @IBOutlet weak var veryrarely: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        suggestionlbl.delegate = self
        self.userId = DoctorManager.shared.caretakerID ?? ""
        self.dateStr = UserDefaults.standard.string(forKey: "SelectedDate") ?? ""
        datelbl.text = self.selectedDate
        if let doctorID = DoctorManager.shared.doctorID {
            print("Doctor ID: \(doctorID)")
            
        } else {
            print("Doctor ID is not available.")
        }
        
        getscore()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func getscore() {
        UntangledMind.APIHandler().getAPIValues(type: Qscore.self, apiUrl: ServiceAPI.questionarie_scoreUrl + "?user_id=\(userId)&date=\(selectedDate)", method: "GET") { [weak self] result in
            switch result {
            case .success(let qscore):
                DispatchQueue.main.async {
                    if let qscore = qscore.data.first {
                        let userScore = qscore.totalScore
                        let userDate = qscore.date
                        let useroptiona = qscore.a
                        let useroptionb = qscore.b
                        let useroptionc = qscore.c
                        let useroptiond = qscore.d
                        let useroptione = qscore.e
                        
                        self?.updateScoreView(score: userScore, date: userDate, a: useroptiona, b: useroptionb, c: useroptionc, d: useroptiond, e: useroptione)
                        
                        self?.everyday.text = "\(qscore.a)"
                        self?.mostdays.text = "\(qscore.b)"
                        self?.somedays.text = "\(qscore.c)"
                        self?.veryrarely.text = "\(qscore.d)"
                        self?.never.text = "\(qscore.e)"
                    } else {
                        print("No data available for the specified user.")
                    }
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    
   
    
    func updateScoreView(score: Int, date: String, a: Int, b: Int, c:Int, d:Int, e:Int) {
        let scorecardView = Score(frame: CGRect(x: 0, y: 0, width: score_card.frame.width, height: score_card.frame.height))
        scorecardView.progressBarColor = UIColor.systemBlue
        scorecardView.setScore(CGFloat(score), customText: "Total Score")
        score_card.addSubview(scorecardView)
        scorecardView.translatesAutoresizingMaskIntoConstraints = false
        let dateLabel = UILabel()
        dateLabel.text = "Date: \(date)"
        dateLabel.textColor = UIColor.black
        score_card.addSubview(dateLabel)
        
    }
    
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)

    }
    
    @IBAction func onpost(_ sender: Any) {
        suggestion()
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        suggestionlbl.text = ""
    }


    func suggestion() {
        let apiURL = ServiceAPI.add_suggestionsUrl
        print("API URL:", apiURL)
        
        guard let suggestionText = suggestionlbl.text else {
            print("Suggestion is empty")
            return
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currentDate = dateFormatter.string(from: Date())
        
        let formData: [String: String] = [
            "user_id": userId,
            "suggestion": suggestionText,
            "date": currentDate
        ]
        
        APIHandler().postAPIValues(type: AddSuggestions.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            print("Result---->", result)
            
            switch result {
            case .success(let response):
                print("Status: \(response.success)")
                print("Message: \(response.message)")
                
                DispatchQueue.main.async {
                    if response.success {
                        
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
}
            
