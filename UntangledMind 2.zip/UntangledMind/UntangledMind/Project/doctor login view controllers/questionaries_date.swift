import UIKit

class questionaries_date: UIViewController {
    
    @IBOutlet weak var day_list: UITableView!
    var datelist: QDate?
    var useridStr = String()
    var noDataLabel: UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        self.useridStr = DoctorManager.shared.caretakerID!
        print(useridStr, "---hi->")
        
        if let doctorID = DoctorManager.shared.doctorID {
            print("Doctor ID: \(doctorID)")
        } else {
            print("Doctor ID is not available.")
        }
        
        day_list.delegate = self
        day_list.dataSource = self
        day_list.register(UINib(nibName: "questionaries_dateTV", bundle: nil), forCellReuseIdentifier: "questionaries_dateTV")
        fetchData()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func fetchData() {
        APIHandler().getAPIValues(type: QDate.self, apiUrl:ServiceAPI.dateUrl+"?user_id=\(useridStr)" , method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.datelist = data
                    self?.day_list.reloadData()
                    
                    // Check if data count is zero and display no data label
                    if data.data.isEmpty {
                        self?.showNoDataLabel()
                    } else {
                        self?.hideNoDataLabel()
                    }
                }
            case .failure(let error):
                print("API Request Error: \(error)")
                // Display no data label in case of API request failure
                DispatchQueue.main.async {
                    self?.showNoDataLabel()
                }
            }
        }
    }
    
    func showNoDataLabel() {
        // Create a label if it doesn't exist
        if noDataLabel == nil {
            noDataLabel = UILabel(frame: CGRect(x: 0, y: 0, width: day_list.bounds.size.width, height: day_list.bounds.size.height))
            noDataLabel?.text = "No data found"
            noDataLabel?.textAlignment = .center
            noDataLabel?.sizeToFit()
            day_list.backgroundView = noDataLabel
        }
    }
    
    func hideNoDataLabel() {
        // Remove the no data label
        noDataLabel?.removeFromSuperview()
        noDataLabel = nil
    }
}

extension questionaries_date: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datelist?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "questionaries_dateTV", for: indexPath) as! questionaries_dateTV
        
        if let datelist = datelist {
            cell.datelbl.text = datelist.data[indexPath.row].date
            UserDefaults.standard.setValue(datelist.data[indexPath.row].date, forKey: "SelectedDate")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "questionarie_ans") as! questionarie_ans
        vc.selectedDate = datelist?.data[indexPath.row].date ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
}
