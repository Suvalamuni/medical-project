//
//  dtopiclist_tvc.swift
//  UntangledMind
//
//  Created by k. Dharani on 30/01/24.
//

import UIKit

class dtopiclist_tvc: UITableViewCell {

    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var topic_id: UILabel!
    @IBOutlet weak var topic_name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
    @IBAction func edit(_ sender: Any) {
        
        
        
    }
}
