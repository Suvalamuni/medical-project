//
//  questionarie_ans.swift
//  hi
//
//  Created by k. Dharani on 21/11/23.
//

import UIKit

class questionarie_ans: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var table: UITableView!
    
    
    var dateStr = String()
    var selectedDate = String()
    var useridStr = String()
    var Anslist: Getans?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        self.useridStr = DoctorManager.shared.caretakerID!
       self.useridStr = UserDefaults.standard.string(forKey: "SelecteduserID") ?? ""
        print(useridStr, "----->")
        self.dateStr = UserDefaults.standard.string(forKey: "SelectedDate") ?? ""
        date.text = self.selectedDate
        print(dateStr, "----->")
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "questionarie_ansTV", bundle: nil), forCellReuseIdentifier: "questionarie_ansTV")
        fetchData()
    }

//    @objc func dismissKeyboard() {
//            view.endEditing(true)
//        }
    func fetchData() {
        
        APIHandler().getAPIValues(type: Getans.self, apiUrl:ServiceAPI.get_ansUrl+"?user_id=\(useridStr)&date=\(self.selectedDate)" , method: "GET") { [weak self] result in

            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    if data.status == true {
                        
                        self?.Anslist = data
                        self?.table.reloadData()
                   
                }else {
                    if let navi = self?.navigationController {
                        DoctorManager.shared.sendMessage(title: "Alert", message:"no adata", navigation: navi)
                    }
                }
            }
            // Debug: Print the response to the console
            case .failure(let error):
                DispatchQueue.main.async {
                    if let navi = self?.navigationController {
                        DoctorManager.shared.sendMessage(title: "Alert", message:"no adata", navigation: navi)
                    }
                }
            }
        }
}
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Anslist?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "questionarie_ansTV", for: indexPath) as? questionarie_ansTV else {
            return UITableViewCell()
        }

        if let ansData = Anslist?.data[indexPath.row] {
            cell.question_id.text = "\(ansData.questionID)"
            cell.questions.text = "\(ansData.questionText)"
            cell.user_ans.text = ansData.userAnswer
        }

        return cell
    }


    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func viewscore(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "questionarie_scorecard")
        as! questionarie_scorecard
        vc.selectedDate = self.dateStr
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            
        return 180.0
        ;
        }
}
