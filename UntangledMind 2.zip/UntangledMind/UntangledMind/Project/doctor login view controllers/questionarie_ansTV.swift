//
//  questionarie_ansTV.swift
//  hi
//
//  Created by k. Dharani on 21/11/23.
//

import UIKit

class questionarie_ansTV: UITableViewCell {

    @IBOutlet weak var question_id: UILabel!
    @IBOutlet weak var questions: UILabel!
    @IBOutlet weak var user_ans: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        questions.font = UIFont.preferredFont(forTextStyle: .body)
               
                questions.adjustsFontSizeToFitWidth = true
                
                questions.minimumScaleFactor = 0.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
