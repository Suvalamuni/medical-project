//
//  testresultTV.swift
//  hi
//
//  Created by k. Dharani on 21/11/23.
//

import UIKit

class testresultTV: UITableViewCell {

    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var topicname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
