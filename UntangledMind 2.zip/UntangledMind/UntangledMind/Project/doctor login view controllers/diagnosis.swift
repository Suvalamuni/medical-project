//
//  diagnosis.swift
//  hi
//
//  Created by k. Dharani on 29/10/23.
//

import Foundation
class diagnosis
{
    var psychoeducation : String!
    var image : String!
    public init(psychoeducation:String, image:String)
    {
        let psychoeducation = psychoeducation
        let image = image
        
        
    }
}
