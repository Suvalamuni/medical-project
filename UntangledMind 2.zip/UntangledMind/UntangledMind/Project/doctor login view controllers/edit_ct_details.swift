

import UIKit

class edit_ct_details: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    var updateCompletion: ((details) -> Void)?
    @IBOutlet weak var user_id: UILabel!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var Age: UITextField!
    @IBOutlet weak var Gender: UITextField!
    @IBOutlet weak var Phone_no: UITextField!
    @IBOutlet weak var Relationship: UITextField!
    @IBOutlet weak var p_Name: UITextField!
    @IBOutlet weak var p_Age: UITextField!
    @IBOutlet weak var p_Gender: UITextField!
    @IBOutlet weak var Diagnosis: UITextField!
    @IBOutlet weak var edit_image: UIButton!
    @IBOutlet weak var profileImage: UIImageView!
    var displaypassword:Passwordmodel?
    var selectedImages: [UIImage] = []
    var selectedUserID: String = ""
    var caretakerDetails: details?
    var caretakerImageURL: String?
    let imagePicker = UIImagePickerController()
    let loaderView = loader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(loaderView)
        loaderView.isHidden = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        getdetails()
        
        p_Gender.delegate = self
        Gender.delegate = self
        Diagnosis.delegate = self
        Phone_no.delegate = self
        let gendertapGesture = UITapGestureRecognizer(target: self, action: #selector(selectGender))
               Gender.addGestureRecognizer(gendertapGesture)
               
               let pgendertapGesture = UITapGestureRecognizer(target: self, action: #selector(pselectGender))
               p_Gender.addGestureRecognizer(pgendertapGesture)
               
               let diagnosisTapGesture = UITapGestureRecognizer(target: self, action: #selector(selectDiagnosis))
               Diagnosis.addGestureRecognizer(diagnosisTapGesture)
        
        user_id.text = caretakerDetails?.userID
        Name.text = caretakerDetails?.name
        if let age = caretakerDetails?.age {
            Age.text = "\(age)"
        }
        
        Gender.text = caretakerDetails?.gender
        Phone_no.text = caretakerDetails?.phoneNo
        Relationship.text = caretakerDetails?.relationship
        p_Name.text = caretakerDetails?.pName
        
        if let age = caretakerDetails?.pAge {
            p_Age.text = "\(age)"
        }
        
        p_Gender.text = caretakerDetails?.pGender
        Diagnosis.text = caretakerDetails?.diagnosis
        if let caretakerImageURL = caretakerImageURL, let imageUrl = URL(string: caretakerImageURL) {
            DispatchQueue.global().async {
                if let imageData = try? Data(contentsOf: imageUrl) {
                    DispatchQueue.main.async {
                        self.profileImage.image = UIImage(data: imageData)
                    }
                }
            }
        }
        
        self.navigationController?.isNavigationBarHidden = true
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
       @IBAction func selectGender(_ sender: Any) {
           let alert = UIAlertController(title: "Select Gender", message: nil, preferredStyle: .actionSheet)
           
           let maleAction = UIAlertAction(title: "Male", style: .default) { _ in
               self.Gender.text = "Male"
           }
           alert.addAction(maleAction)
           
           let femaleAction = UIAlertAction(title: "Female", style: .default) { _ in
               self.Gender.text = "Female"
           }
           alert.addAction(femaleAction)
           
           let otherAction = UIAlertAction(title: "Other", style: .default) { _ in
               self.Gender.text = "Other"
           }
           alert.addAction(otherAction)
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           alert.addAction(cancelAction)
           
           present(alert, animated: true, completion: nil)
       }
       
       @IBAction func pselectGender(_ sender: Any) {
           let alert = UIAlertController(title: "Select Gender", message: nil, preferredStyle: .actionSheet)
           
           let maleAction = UIAlertAction(title: "Male", style: .default) { _ in
               self.p_Gender.text = "Male"
           }
           alert.addAction(maleAction)
           
           let femaleAction = UIAlertAction(title: "Female", style: .default) { _ in
               self.p_Gender.text = "Female"
           }
           alert.addAction(femaleAction)
           
           let otherAction = UIAlertAction(title: "Other", style: .default) { _ in
               self.p_Gender.text = "Other"
           }
           alert.addAction(otherAction)
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           alert.addAction(cancelAction)
           
           present(alert, animated: true, completion: nil)
       }

       @IBAction func selectDiagnosis(_ sender: Any) {
           let alert = UIAlertController(title: "Select Diagnosis", message: nil, preferredStyle: .actionSheet)
           
           let bpaAction = UIAlertAction(title: "BPA", style: .default) { _ in
               self.Diagnosis.text = "BPA"
           }
           alert.addAction(bpaAction)
           
           let schizophreniaAction = UIAlertAction(title: "Schizophrenia", style: .default) { _ in
               self.Diagnosis.text = "Schizophrenia"
           }
           alert.addAction(schizophreniaAction)
           
           let alcoholDependenceAction = UIAlertAction(title: "Alcohol Dependence", style: .default) { _ in
               self.Diagnosis.text = "Alcohol Dependence"
           }
           alert.addAction(alcoholDependenceAction)
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           alert.addAction(cancelAction)
           
           present(alert, animated: true, completion: nil)
       }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func edit(_ sender: Any) {
        presentImagePicker()
    }
    
    @IBAction func save(_ sender: Any) {
    
        guard let phoneNumber = Phone_no.text, !phoneNumber.isEmpty else {
                   print("Phone number is empty")
                   displayAlert(message: "Please enter a phone number.")
                   return
               }
           
               guard validatePhoneNumber(phoneNumber) else {
                   print("Invalid phone number: \(phoneNumber)")
                   displayAlert(message: "Please enter a 10-digit phone number.")
                   return
               }
              
               updateAPI()
           }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
           if textField == Phone_no {
               // Check if the new input is numeric
               let allowedCharacterSet = CharacterSet.decimalDigits
               let characterSet = CharacterSet(charactersIn: string)
               if !allowedCharacterSet.isSuperset(of: characterSet) && !string.isEmpty {
                   // If the new input is not numeric, display an alert
                   displayAlert(message: "Please enter numbers only for phone number.")
                   return false
               }

               // Check if the total length of text after the change exceeds 10 characters
               let currentText = (textField.text ?? "") as NSString
               let newText = currentText.replacingCharacters(in: range, with: string) as NSString
               if newText.length > 10 {
                   // If the total length exceeds 10, display an alert
                   displayAlert(message: "Please enter a valid 10-digit phone number.")
                   return false
               }
           }
           return true
       }

    func getdetails() {
       

        let apiUrl = "\(ServiceAPI.d_passwordUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
        print(apiUrl)

        APIHandler().getAPIValues(type: Passwordmodel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let pass):
                DispatchQueue.main.async {
                    self?.displaypassword = pass
                    self?.password.text = pass.data.first?.password
                    
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    func displayAlert(message: String) {
        let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
           

        func validatePhoneNumber(_ phoneNumber: String) -> Bool {
            let phoneRegex = "^\\d{10}$"
            let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
            return phonePredicate.evaluate(with: phoneNumber)
        }

    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
            profileImage.image = pickedImage
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default) { _ in
            self.openCamera()
        })
        alert.addAction(UIAlertAction(title: "Gallery", style: .default) { _ in
            self.openGallery()
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func updateAPI() {
        guard !selectedImages.isEmpty || !user_id.text!.isEmpty || !password.text!.isEmpty ||
                !Name.text!.isEmpty || !Age.text!.isEmpty || !Gender.text!.isEmpty ||
                !Phone_no.text!.isEmpty || !Relationship.text!.isEmpty ||
                !p_Name.text!.isEmpty || !p_Age.text!.isEmpty || !p_Gender.text!.isEmpty ||
                !Diagnosis.text!.isEmpty else {
            print("No details to update")
            return
        }
        let imageData: Data? = selectedImages.first?.jpegData(compressionQuality: 1.0)
      
        
        var formData: [String: String] = [
            "user_id": user_id.text ?? "",
            "password": password.text ?? "",
            "Name" : Name.text ?? "",
            "Age" : Age.text ?? "",
            "gender" : Gender.text ?? "",
            "phone_no" : Phone_no.text ?? "",
            "p_Name" : p_Name.text ?? "",
            "p_Age" : p_Age.text ?? "",
            "p_Gender" : p_Gender.text ?? "",
            "Diagnosis" : Diagnosis.text ?? "",
            "Relationship" : Relationship.text ?? "",
        ]
        
        
        if let imageData = imageData {
            formData["Caretaker_image"] = imageData.base64EncodedString()
        }
        
        
        let textFields: [UITextField] = [password, Name, Age, Gender, Phone_no, Relationship, p_Name, p_Age, p_Gender, Diagnosis]
        
        for textField in textFields {
            if let text = textField.text, !text.isEmpty {
                formData[textField.placeholder ?? ""] = text
            }
        }
        
        APIHandler().postAPIValues(type: update_ctdetails.self, apiUrl: ServiceAPI.update_ct_details_Url, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let data):
                print(data.message)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Success", message: "Details updated successfully.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(identifier: "CaretakerInfoViewController") as! CaretakerInfoViewController
                        vc.selectedUserID = self.selectedUserID
                        vc.fetchCaretakerDetails()

                        self.navigationController?.popViewController(animated: false)
                    }))
                    self.present(alert, animated: true, completion: nil)
                }
            case .failure(let error):
                print("Network Error: \(error)")
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong \(error)", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        // Handle the error gracefully
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
   
}
