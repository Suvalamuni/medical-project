

import UIKit

class d_topicques: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var selectedSubTopicId: String?
    var qnsAnsData: gettopicqns?
    var currentQuestionIndex: Int = 0
    var selectedSubTopic = String()
    var selectedQuestion: [topicqns]?

    @IBOutlet weak var topicquescell: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        currentQuestionIndex = 0
        GetQnsAnsList()
        topicquescell.register(UINib(nibName: "d_topicquestvc", bundle: nil), forCellReuseIdentifier: "testCellReuseIdentifier")
        topicquescell.dataSource = self
        topicquescell.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
       
        GetQnsAnsList()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }


   

    func GetQnsAnsList() {
           APIHandler().getAPIValues(type: gettopicqns.self, apiUrl: ServiceAPI.videoQuestionaryUrl + "?subtopic_name=\(selectedSubTopic)", method: "GET") { result in
               switch result {
               case .failure(let error):
                   print(error)
               case .success(let data):
                   self.qnsAnsData = data
                   self.selectedQuestion = data.data
                   DispatchQueue.main.async {
                       self.topicquescell.reloadData()
                   }
               }
           }
       }

       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           // Return the number of rows in your data source
           return qnsAnsData?.data.count ?? 0
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "testCellReuseIdentifier", for: indexPath) as! d_topicquestvc

           if let qnsAnsData = self.qnsAnsData?.data[indexPath.row] {
               cell.questiontext.text = qnsAnsData.question
               cell.ques_id.text = "\(qnsAnsData.questionID)"
               cell.op1.text = qnsAnsData.optionA
               cell.op2.text = qnsAnsData.optionB
               cell.op3.text = qnsAnsData.optionC
               cell.op4.text = qnsAnsData.optionD
               cell.questionID = qnsAnsData.questionID
               
           }

           return cell
       }

       func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           return 300.0
       }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "edittopicques") as! edittopicques
        vc.selectedSubtopicId = selectedSubTopicId
            vc.selectedQuestion = self.qnsAnsData?.data[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    
    

