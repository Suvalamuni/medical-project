import UIKit

class CaretakerInfoViewController: UIViewController {
    @IBOutlet weak var bck: UIButton!
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var userIDLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var phoneNoLabel: UILabel!
    @IBOutlet weak var relationshipLabel: UILabel!
    @IBOutlet weak var pNameLabel: UILabel!
    @IBOutlet weak var pAgeLabel: UILabel!
    @IBOutlet weak var pGenderLabel: UILabel!
    @IBOutlet weak var diagnosisLabel: UILabel!
    
    var selectedUserID: String = ""
    var caretakerdetail: details?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.selectedUserID = DoctorManager.shared.caretakerID!
        print(selectedUserID)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
        fetchCaretakerDetails()
    }
   
    @IBAction func whatsbtn(_ sender: Any) {
            guard let phoneNumber = phoneNoLabel.text else {
                print("Phone number is nil")
                return
            }
           
            if let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(phoneNumber)") {
                if UIApplication.shared.canOpenURL(whatsappURL) {
                   
                    UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
                } else {
                   
                    let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(okAction)
                    present(alertController, animated: true, completion: nil)
                }
            }
        }

    
    @IBAction func back(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
       
    }
    @IBAction func viewactivity(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "activitiesvc") as! activitiesvc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func edit(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "edit_ct_details") as! edit_ct_details
        
        vc.caretakerDetails = caretakerdetail
        vc.caretakerImageURL = caretakerdetail?.caretakerImage
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func fetchCaretakerDetails() {
        guard let userId = selectedUserID.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("User ID is nil")
            return
        }
        let apiUrl = "\(ServiceAPI.Caretaker_detailsUrl)user_id=\(userId)"
        print(userId)
        
        APIHandler().getAPIValues(type: details.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let caretakerDetail):
                DispatchQueue.main.async {
                    self?.caretakerdetail = caretakerDetail
                    if let urlString = self?.caretakerdetail?.caretakerImage,
                       let url = URL(string: ServiceAPI.baseUrl + urlString) {
                        URLSession.shared.dataTask(with: url) { (data, response, error) in
                            if let data = data, let image = UIImage(data: data) {
                                DispatchQueue.main.async {
                                    self?.images.image = image
                                }
                            }
                        }.resume()
                    }


                    self?.userIDLabel.text = caretakerDetail.userID
                    self?.nameLabel.text = caretakerDetail.name
                    self?.ageLabel.text = "\(caretakerDetail.age)"
                    self?.genderLabel.text = caretakerDetail.gender
                    self?.phoneNoLabel.text = caretakerDetail.phoneNo
                    self?.relationshipLabel.text = caretakerDetail.relationship
                    self?.pNameLabel.text = caretakerDetail.pName
                    self?.pAgeLabel.text = "\(caretakerDetail.pAge)"
                    self?.pGenderLabel.text = caretakerDetail.pGender
                    self?.diagnosisLabel.text = caretakerDetail.diagnosis
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
}
