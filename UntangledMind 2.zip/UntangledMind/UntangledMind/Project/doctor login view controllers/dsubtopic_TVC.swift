//
//  dsubtopic_TVC.swift
//  UntangledMind
//
//  Created by k. Dharani on 01/02/24.
//

import UIKit

class dsubtopic_TVC: UITableViewCell {

    @IBOutlet weak var subtopic_id: UILabel!
    @IBOutlet weak var subtopic_name: UILabel!
    @IBOutlet weak var editButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
