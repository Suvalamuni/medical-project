import UIKit
import AVKit
import AVFoundation
import MobileCoreServices

class Edit_videos: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate  {
    
    @IBOutlet weak var subtopicname: UILabel!
    @IBOutlet weak var descript: UITextView!
    @IBOutlet weak var video_player: UIView!
    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    var videoDescription: String = ""
    var selectedVideoURL: URL?
    var selectedSubTopicId: String = ""
    var  selectedSubTopic: String = ""
    var player: AVPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        descript.text = videoDescription
        subtopicname.text = selectedSubTopic
        descript.delegate = self
        if let videoURL = selectedVideoURL {
            playVideo(url: videoURL)
            addTapGestureToVideoPlayer()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        pauseVideo()
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == videoDescription {
            textView.text = ""
        }
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func editvideo(_ sender: Any) {
        presentImagePicker()
    }
    
    @IBAction func save(_ sender: Any) {
        updateVideos()
    }
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Media", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Choose Video", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.sourceType = .camera
            imagePicker.mediaTypes = [kUTTypeMovie as String] // Set media type to video
            imagePicker.delegate = self
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        imagePicker.mediaTypes = [kUTTypeMovie as String] // Set media type to video
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
            selectedVideoURL = videoURL
            DispatchQueue.main.async {
                self.playVideo(url: videoURL)
                self.addTapGestureToVideoPlayer()
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func playVideo(url: URL) {
        showLoader()
        DispatchQueue.main.async { [weak self] in
            if let player = self?.player {
                player.pause()
                player.replaceCurrentItem(with: AVPlayerItem(url: url))
            } else {
                // Initialize player if not already done
                self?.player = AVPlayer(url: url)
                let playerLayer = AVPlayerLayer(player: self?.player)
                playerLayer.frame = self?.video_player.bounds ?? CGRect.zero
                self?.video_player.layer.addSublayer(playerLayer)
            }
            
            // Ensure player is not nil before playing
            if let player = self?.player {
                player.play()
            } else {
                print("Failed to initialize AVPlayer.")
            }
        }
    }
    
    func pauseVideo() {
        if let player = player {
            player.pause()
        }
    }
    
    func addTapGestureToVideoPlayer() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTapGesture(_:)))
        video_player.addGestureRecognizer(tapGesture)
    }
    
    @objc func handleTapGesture(_ sender: UITapGestureRecognizer) {
        if let player = player {
            if player.rate != 0 && player.error == nil {
                player.pause()
            } else {
                player.play()
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func updateVideos() {
        guard let videoURL = selectedVideoURL else {
            print("Video URL is nil.")
            return
        }
        
        let apiURL = ServiceAPI.updatevideoUrl
        print("API URL:", apiURL)
        
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        
        let formData: [String: String] = [
            "subtopic_id": selectedSubTopicId,
            "description": descript.text ?? "",
        ]
        
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        
        // Append video data
        let videoData = try! Data(contentsOf: videoURL)
        body.append(contentsOf: "--\(boundary)\r\n".utf8)
        body.append(contentsOf: "Content-Disposition: form-data; name=\"video\"; filename=\"\(UUID().uuidString).mov\"\r\n".utf8)
        body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
        body.append(contentsOf: videoData)
        body.append(contentsOf: "\r\n".utf8)
        
        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                    
                    DispatchQueue.main.async {
                        self?.hideLoader()

                        // Show alert
                        let alertController = UIAlertController(title: "Success", message: "Details updated successfully", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            // Navigate back to the previous view controller
                            self?.navigationController?.popViewController(animated: true)
                        }))
                        self?.present(alertController, animated: true, completion: nil)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    func showLoader() {
        loader.isHidden = false
        loader.startAnimating()
    }
    
    func hideLoader() {
        loader.stopAnimating()
        loader.isHidden = true
    }
}
