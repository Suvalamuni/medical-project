//
//  topicadvice.swift
//  UntangledMind
//
//  Created by k. Dharani on 22/02/24.
//

import UIKit

class topicadvice: UIViewController, UITextViewDelegate  {
    var userId: String = ""

    @IBOutlet weak var suggestionlbl: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        suggestionlbl.delegate = self
        self.userId = DoctorManager.shared.caretakerID ?? ""

      
    }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)

    }
    
    @IBAction func onpost(_ sender: Any) {
        
        suggestion()
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        suggestionlbl.text = ""
    }

    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func suggestion() {
        let apiURL = ServiceAPI.add_suggestionsUrl
        print("API URL:", apiURL)
        
        guard let suggestionText = suggestionlbl.text else {
            print("Suggestion is empty")
            return
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currentDate = dateFormatter.string(from: Date())
        
        let formData: [String: String] = [
            "user_id": userId,
            "suggestion": suggestionText,
            "date": currentDate
        ]
        
        APIHandler().postAPIValues(type: AddSuggestions.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            print("Result---->", result)
            
            switch result {
            case .success(let response):
                print("Status: \(response.success)")
                print("Message: \(response.message)")
                
                DispatchQueue.main.async {
                    if response.success {
                        // Show success popup
                        let alert = UIAlertController(title: "Success", message: "Advice added successfully", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                            
                            for controller in self.navigationController!.viewControllers as Array {
                                                        if controller.isKind(of: testresults.self) {
                                                            self.navigationController!.popToViewController(controller, animated: true)
                                                            break
                                                        }
                                                    }
                                                })
                                                self.present(alert, animated: true, completion: nil)
                    } else {
                        // Show failure popup
                        let alert = UIAlertController(title: "Error", message: "Something went wrong. Please try again later.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
                // Show failure popup
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Error", message: "Failed to add advice. Please check your internet connection and try again.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }

    
}
