import UIKit

class caretaker_details: UIViewController,  UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var user_id: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var Age: UITextField!
    @IBOutlet weak var Gender: UITextField!
    @IBOutlet weak var Phone_no: UITextField!
    @IBOutlet weak var Relationship: UITextField!
    @IBOutlet weak var p_Name: UITextField!
    @IBOutlet weak var p_Age: UITextField!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var p_Gender: UITextField!
    @IBOutlet weak var Diagnosis: UITextField!
    var selectedImages: [UIImage] = []
    var body = Data()
    let imagePicker = UIImagePickerController()
    let loaderView = loader()
    var responseMessage = ""
    
    
    @IBOutlet weak var caretakerImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        self.navigationController?.isNavigationBarHidden = true
        Gender.delegate = self
        p_Gender.delegate = self
        Diagnosis.delegate = self
        Phone_no.delegate = self
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        view.addSubview(loaderView)
        loaderView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            loaderView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loaderView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        let gendertapGesture = UITapGestureRecognizer(target: self, action: #selector(selectGender))
        Gender.addGestureRecognizer(gendertapGesture)
        let pgendertapGesture = UITapGestureRecognizer(target: self, action: #selector(pselectGender))
        p_Gender.addGestureRecognizer(pgendertapGesture)
        let diagnosisTapGesture = UITapGestureRecognizer(target: self, action: #selector(selectDiagnosis))
        Diagnosis.addGestureRecognizer(diagnosisTapGesture)
        
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func selectGender(_ sender: Any) {
        let alert = UIAlertController(title: "Select Gender", message: nil, preferredStyle: .actionSheet)
        
        let maleAction = UIAlertAction(title: "Male", style: .default) { _ in
            // Handle selection of Male
            self.Gender.text = "Male"
        }
        alert.addAction(maleAction)
        
        let femaleAction = UIAlertAction(title: "Female", style: .default) { _ in
            // Handle selection of Female
            self.Gender.text = "Female"
        }
        alert.addAction(femaleAction)
        
        let otherAction = UIAlertAction(title: "Other", style: .default) { _ in
            // Handle selection of Other
            self.Gender.text = "Other"
        }
        alert.addAction(otherAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    @IBAction func pselectGender(_ sender: Any) {
        let alert = UIAlertController(title: "Select Gender", message: nil, preferredStyle: .actionSheet)
        
        let maleAction = UIAlertAction(title: "Male", style: .default) { _ in
            self.p_Gender.text = "Male"
        }
        alert.addAction(maleAction)
        
        let femaleAction = UIAlertAction(title: "Female", style: .default) { _ in
            self.p_Gender.text = "Female"
        }
        alert.addAction(femaleAction)
        
        let otherAction = UIAlertAction(title: "Other", style: .default) { _ in
            self.p_Gender.text = "Other"
        }
        alert.addAction(otherAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    @IBAction func selectDiagnosis(_ sender: Any) {
        let alert = UIAlertController(title: "Select Diagnosis", message: nil, preferredStyle: .actionSheet)
        
        let bpaAction = UIAlertAction(title: "BPAD", style: .default) { _ in
            // Handle selection of BPA
            self.Diagnosis.text = "BPA"
        }
        alert.addAction(bpaAction)
        
        let schizophreniaAction = UIAlertAction(title: "Schizophrenia", style: .default) { _ in
            // Handle selection of Schizophrenia
            self.Diagnosis.text = "Schizophrenia"
        }
        alert.addAction(schizophreniaAction)
        
        let alcoholDependenceAction = UIAlertAction(title: "Alcohol Dependence", style: .default) { _ in
            // Handle selection of Alcohol Dependence
            self.Diagnosis.text = "Alcohol Dependence"
        }
        alert.addAction(alcoholDependenceAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    
    @IBAction func Add_image(_ sender: Any) {
        presentImagePicker()
    }
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
    }
    @IBAction func onsave(_ sender: Any) {
        
        guard !user_id.text!.isEmpty, !password.text!.isEmpty, !Name.text!.isEmpty, !Age.text!.isEmpty, !Gender.text!.isEmpty, !Phone_no.text!.isEmpty, !Relationship.text!.isEmpty, !p_Name.text!.isEmpty, !p_Age.text!.isEmpty, !p_Gender.text!.isEmpty, !Diagnosis.text!.isEmpty, !selectedImages.isEmpty else {
            showAlert(message: "All fields are required, including the image.")
            return
        }
        
        if let phoneNumber = Phone_no.text, phoneNumber.count != 10 {
            showAlert(message: "Phone number should be 10 digits long.")
            return
        }
        showLoader()
        
        ADDUser { success in
            if success {
                self.hideLoader()
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }
            } else {
                self.hideLoader()
                DispatchQueue.main.async {
                    self.showAlert(message: self.responseMessage == "User already exists." ? self.responseMessage : "Failed to add user. Please try again.")
                }
            }
        }
    }
    
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
            
            caretakerImageView.image = pickedImage
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == Phone_no {
            // Check if the new string contains only digits
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            if !allowedCharacters.isSuperset(of: characterSet) && !string.isEmpty {
                
                Utlis.showAlert(title: "", message: "Please enter digits only for phone number.", view: self)
                return false
            }
            
            
            let currentText = textField.text ?? ""
            guard let stringRange = Range(range, in: currentText) else { return false }
            let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
            if updatedText.count > 10 {
                Utlis.showAlert(title: "", message: "Phone number should be 10 digits long.", view: self)
                return false
            }
        }
        return true
    }
    
    // Function to show an alert with a given message
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func showLoader() {
        loaderView.startAnimating()
    }
    
    func hideLoader() {
        loaderView.stopAnimating()
    }
    
    func ADDUser(_ completion: @escaping(Bool)->Void) {
        guard !user_id.text!.isEmpty, !password.text!.isEmpty, !Name.text!.isEmpty, !Age.text!.isEmpty, !Gender.text!.isEmpty, !Phone_no.text!.isEmpty, !Relationship.text!.isEmpty, !p_Name.text!.isEmpty, !p_Age.text!.isEmpty, !p_Gender.text!.isEmpty, !Diagnosis.text!.isEmpty, !selectedImages.isEmpty else {
            print("All fields are mandatory.")
            return
        }
        let apiURL = ServiceAPI.Add_CaretakerUrl
        print("API URL:", apiURL)
        
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData: [String: String] = [
            "user_id": user_id.text ?? "",
            "password": password.text ?? "",
            "Name": Name.text ?? "",
            "Age": Age.text ?? "",
            "gender": Gender.text ?? "",
            "phone_no": Phone_no.text ?? "",
            "Relationship": Relationship.text ?? "",
            "p_Name": p_Name.text ?? "",
            "p_Age": p_Age.text ?? "",
            "p_Gender": p_Gender.text ?? "",
            "Diagnosis": Diagnosis.text ?? ""
        ]
        
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        
        
        let fieldNames = ["Caretaker_image"]
        
        for (index, image) in selectedImages.enumerated() {
            let fieldName = fieldNames[index]
            
            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)
            
            
        }
        
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                
                DispatchQueue.main.async {
                    self.showAlert(message: "An error occurred. Please try again.")
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any], let msg = json["message"] as? String  {
                            print(json["message"])
                            self.responseMessage = msg
                        }
                    } catch {
                        print("Error converting data to JSON: \(error)")
                    }
                    if self.responseMessage == "User already exists." {
                        completion(false)
                    } else if 200..<300 ~= httpResponse.statusCode {
                        DispatchQueue.main.async {
                            Utlis.showAlertWithCompletion(message: self.responseMessage, view: self) {
                                completion(true)
                            }
                            
                        }
                    } else if httpResponse.statusCode == 409 {
                        // User already exists
                        DispatchQueue.main.async {
                            self.showAlert(message: self.responseMessage)
                            completion(true)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.showAlert(message: "Failed to save details. Please try again.")
                            completion(false)
                        }
                    }
                }
            }
        }
        
        task.resume()
    }
    
}
