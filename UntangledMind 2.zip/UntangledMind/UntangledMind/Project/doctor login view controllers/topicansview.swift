import UIKit

class topicansview: UIViewController {
    
    @IBOutlet weak var topicTable: UITableView! 
    
        var selectedDate = String()
        var dateStr = String()
        var useridStr = String()
        var selectedsubtopic = String()
        var subtopicstr = String()
        var answers: GetTopicans?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                    self.view.addGestureRecognizer(tapGesture)
           
            topicTable.register(UINib.init(nibName: "topicans_TVC", bundle: nil), forCellReuseIdentifier: "topicans_TVC")
            
            
            self.useridStr = DoctorManager.shared.caretakerID ?? ""
            self.dateStr = UserDefaults.standard.string(forKey: "SelectedDate") ?? ""
            self.subtopicstr = UserDefaults.standard.string(forKey: "selectedsubtopic") ?? ""
            fetchData()
            
        }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func onadd(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "topicadvice")
        as! topicadvice
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
    func fetchData() {
            
            APIHandler().getAPIValues(type: GetTopicans.self, apiUrl:ServiceAPI.gettopicansUrl+"?user_id=\(useridStr)&date=\(self.selectedDate)&subtopic_name=\(self.selectedsubtopic)" , method: "GET") { [weak self] result in
                
                switch result {
                case .success(let data):
                    print(data)
                    DispatchQueue.main.async {
                        self?.answers = data
                        self?.topicTable.reloadData()
                    }
                    // Debug: Print the response to the console
                case .failure(let error):
                    print("API Request Error: \(error)")
                }
            }
        }
       
    }
    extension topicansview : UITabBarDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            print("NUmber of rows in table--->",answers?.data.count)
            return answers?.data.count ?? 0
        }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "topicans_TVC", for: indexPath) as? topicans_TVC else {
                return UITableViewCell()
            }
                    if let ansData = answers?.data[indexPath.row] {
                        cell.ques_id.text = "\(ansData.questionID)"
                        cell.question.text = "\(ansData.question)"
                        cell.answer.text = ansData.answer
                    }
            return cell
        }
    }
