//
//  d_topiclist.swift
//  UntangledMind
//
//  Created by k. Dharani on 30/01/24.
//

import UIKit

class d_topiclist:UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var TABLE: UITableView!
    var topiclist: Topics?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        
        TABLE.delegate = self
        TABLE.dataSource = self
        TABLE.register(UINib(nibName: "dtopiclist_tvc", bundle: nil), forCellReuseIdentifier: "dtopiclist_tvc")
        
    }
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
       
        fetchData()
        }
    
    func fetchData() {
        APIHandler().getAPIValues(type: Topics.self, apiUrl: ServiceAPI.topic_listUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.topiclist = data
                    self?.TABLE.reloadData()
                }
            case .failure(let error):
                print("API Request Error: \(error)")
            }
        }
    }
//    @objc func dismissKeyboard() {
//            view.endEditing(true)
//        }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topiclist?.data.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(identifier: "d_subtopicsViewController") as! d_subtopicsViewController
        if let selectedTopic = topiclist?.data[indexPath.row] {
            vc.selectedTopicName = selectedTopic.topicName
        }
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "dtopiclist_tvc", for: indexPath) as! dtopiclist_tvc
        
        if let topic = topiclist?.data[indexPath.row] {
            //            if topic.image != "" {
            //                let url = URL(string:  topic.image)!
            //                DispatchQueue.global().async {
            //                    if let imageData = try? Data(contentsOf: url) {
            //                        DispatchQueue.main.async {
            //                            // Assuming edit_image is your UIImageView
            //                            cell.imagelist.image = UIImage(data: imageData)
            //                        }
            //                    }
            //                }
            //            }
            
            cell.topic_name.text = topic.topicName
            cell.topic_id.text = topic.topicID
            cell.editButton.tag = indexPath.row
            cell.editButton.addTarget(self, action: #selector(editButtonTapped(_:)), for: .touchUpInside)
        }
        
        return cell
    }
    @objc func editButtonTapped(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let editVC = storyBoard.instantiateViewController(identifier: "edittopiclist") as! edittopiclist
        
        // Pass the selected index to edittopiclist
        editVC.topiclist = topiclist
        editVC.selectedTopicIndex = sender.tag
        
        self.navigationController?.pushViewController(editVC, animated: true)
    }
}

