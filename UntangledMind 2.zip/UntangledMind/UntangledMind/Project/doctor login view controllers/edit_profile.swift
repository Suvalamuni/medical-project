
import UIKit

class edit_profile:UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    var updateCompletion: ((docdetails) -> Void)?
    @IBOutlet weak var user_id: UILabel!
    @IBOutlet weak var passwordLabel: UITextField!
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var ageLabel: UITextField!
    @IBOutlet weak var genderLabel: UITextField!
    @IBOutlet weak var phonenoLabel: UITextField!
    @IBOutlet weak var designationLabel: UITextField!
    @IBOutlet weak var institutionLabel: UITextField!
    @IBOutlet weak var doctimage: UIImageView!
    var doctorDetail: docdetails?
    var selectedImages: [UIImage] = []
    var selectedUserID: String = ""
    var doctorImageURL: String?
    let imagePicker = UIImagePickerController()
    let loaderView = loader()
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        genderLabel.delegate = self
        let gendertapGesture = UITapGestureRecognizer(target: self, action: #selector(selectGender))
        genderLabel.addGestureRecognizer(gendertapGesture)
       
        user_id.text = doctorDetail?.userID
        nameLabel.text = doctorDetail?.name
        ageLabel.text = doctorDetail?.age
        genderLabel.text = doctorDetail?.gender
        phonenoLabel.text = doctorDetail?.phoneNo
        passwordLabel.text = doctorDetail?.password
        institutionLabel.text = doctorDetail?.institution
        designationLabel.text = doctorDetail?.designation
        emailLabel.text = doctorDetail?.emailID
        if let doctorImageURL = doctorImageURL, let imageUrl = URL(string: ServiceAPI.baseUrl + doctorImageURL) {
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: imageUrl) {
                        DispatchQueue.main.async {
                            self.doctimage.image = UIImage(data: imageData)
                        }
                    }
                }
            }
        self.navigationController?.isNavigationBarHidden = true
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func selectGender(_ sender: Any) {
        let alert = UIAlertController(title: "Select Gender", message: nil, preferredStyle: .actionSheet)
        
        let maleAction = UIAlertAction(title: "Male", style: .default) { _ in
            self.genderLabel.text = "Male"
        }
        alert.addAction(maleAction)
        
        let femaleAction = UIAlertAction(title: "Female", style: .default) { _ in
            self.genderLabel.text = "Female"
        }
        alert.addAction(femaleAction)
        
        let otherAction = UIAlertAction(title: "Other", style: .default) { _ in
            self.genderLabel.text = "Other"
        }
        alert.addAction(otherAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }

    @IBAction func editimg(_ sender: Any) {
        presentImagePicker()
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func save(_ sender: Any) {
    
        guard let phoneNumber = phonenoLabel.text, !phoneNumber.isEmpty else {
                   print("Phone number is empty")
                   displayAlert(message: "Please enter a phone number.")
                   return
               }
           
               guard validatePhoneNumber(phoneNumber) else {
                   print("Invalid phone number: \(phoneNumber)")
                   displayAlert(message: "Please enter a 10-digit phone number.")
                   return
               }
              
               updateAPI()
           }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
           if textField == phonenoLabel {
               // Check if the new input is numeric
               let allowedCharacterSet = CharacterSet.decimalDigits
               let characterSet = CharacterSet(charactersIn: string)
               if !allowedCharacterSet.isSuperset(of: characterSet) && !string.isEmpty {
                   // If the new input is not numeric, display an alert
                   displayAlert(message: "Please enter numbers only for phone number.")
                   return false
               }

               // Check if the total length of text after the change exceeds 10 characters
               let currentText = (textField.text ?? "") as NSString
               let newText = currentText.replacingCharacters(in: range, with: string) as NSString
               if newText.length > 10 {
                   // If the total length exceeds 10, display an alert
                   displayAlert(message: "Please enter a valid 10-digit phone number.")
                   return false
               }
           }
           return true
       }
    func displayAlert(message: String) {
        let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
           

        func validatePhoneNumber(_ phoneNumber: String) -> Bool {
            let phoneRegex = "^\\d{10}$"
            let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
            return phonePredicate.evaluate(with: phoneNumber)
        }

    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
            doctimage.image = pickedImage
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default) { _ in
            self.openCamera()
        })
        alert.addAction(UIAlertAction(title: "Gallery", style: .default) { _ in
            self.openGallery()
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func updateAPI() {
        guard !selectedImages.isEmpty || !user_id.text!.isEmpty || !passwordLabel.text!.isEmpty ||
                !nameLabel.text!.isEmpty || !ageLabel.text!.isEmpty || !genderLabel.text!.isEmpty ||
                !phonenoLabel.text!.isEmpty || !institutionLabel.text!.isEmpty ||
                !designationLabel.text!.isEmpty || !emailLabel.text!.isEmpty else {
                    print("No details to update")
                    return
                }
        let imageData: Data? = selectedImages.first?.jpegData(compressionQuality: 1.0)
        
        
        var formData: [String: String] = [
            "user_id": user_id.text ?? "",
            "password": passwordLabel.text ?? "",
            "Name" : nameLabel.text ?? "",
            "Age" : ageLabel.text ?? "",
            "gender" : genderLabel.text ?? "",
            "phone_no" : phonenoLabel.text ?? "",
            "institution" : institutionLabel.text ?? "",
            "designation" : designationLabel.text ?? "",
            "email_id" : emailLabel.text ?? "",
            
        ]
        if let imageData = imageData {
            formData["doctorimage"] = imageData.base64EncodedString()
        }
        let textFields: [UITextField] = [passwordLabel, nameLabel, ageLabel, genderLabel, phonenoLabel, institutionLabel, designationLabel, emailLabel]
        for textField in textFields {
            if let text = textField.text, !text.isEmpty {
                formData[textField.placeholder ?? ""] = text
            }
        }
    
    APIHandler().postAPIValues(type: Editdocdetail.self, apiUrl: ServiceAPI.editdoctordetailsUrl, method: "POST", formData: formData) { [weak self] result in
        guard let self = self else { return }
        
        switch result {
        case .success(let data):
            print(data.message)
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Success", message: "Details updated successfully.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(identifier: "view_profille") as! view_profille
                    vc.selectedUserID = self.selectedUserID
                    vc.fetchDoctorDetails()

                    self.navigationController?.popViewController(animated: false)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        case .failure(let error):
            print("Network Error: \(error)")
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Warning", message: "Something Went Wrong \(error)", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                    // Handle the error gracefully
                })
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}

}
//UIViewController, UITextFieldDelegate {
//
//    @IBOutlet weak var user_id: UILabel!
//    @IBOutlet weak var Name: UITextField!
//    @IBOutlet weak var email_id: UITextField!
//    @IBOutlet weak var phone_no: UITextField!
//    @IBOutlet weak var institution1: UITextField!
//    @IBOutlet weak var designation: UITextField!
//    
//    var doctorDetails: DoctorProfile?
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
//        displayDoctorDetails()
//        phone_no.delegate = self
//    }
//    @objc func dismissKeyboard() {
//            view.endEditing(true)
//        }
//    func displayDoctorDetails() {
//        guard let doctor = self.doctorDetails?.data.first else {
//            return
//        }
//        
//        user_id.text = String(doctor.userID)
//        Name.text = doctor.name
//        email_id.text = doctor.emailID
//        phone_no.text = doctor.phoneNo
//        institution1.text = doctor.institution
//        designation.text = doctor.designation
//    }
//    
//    @IBAction func back(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//    }
//    
//    @IBAction func save(_ sender: Any) {guard let email = email_id.text, !email.isEmpty else {
//        displayAlert(message: "Please enter an email address.")
//        return
//    }
//    
//    guard validateEmail(email) else {
//        displayAlert(message: "Please enter a valid email address.")
//        return
//    }
//    
//    guard let phoneNumber = phone_no.text, !phoneNumber.isEmpty else {
//        displayAlert(message: "Please enter a phone number.")
//        return
//    }
//    
//    guard validatePhoneNumber(phoneNumber) else {
//        displayAlert(message: "Please enter a 10-digit phone number.")
//        return
//    }
//    
//    saveAPI()
//}
//    
//
//func displayAlert(message: String) {
//    let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
//    let okAction = UIAlertAction(title: "OK", style: .default)
//    alert.addAction(okAction)
//    present(alert, animated: true, completion: nil)
//}
//        func validateEmail(_ email: String) -> Bool {
//            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.com"
//            let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
//            return emailPredicate.evaluate(with: email)
//        }
//
//
//    func validatePhoneNumber(_ phoneNumber: String) -> Bool {
//        let phoneRegex = "^\\d{10}$"
//        let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
//        return phonePredicate.evaluate(with: phoneNumber)
//    }
//
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//            if textField == phone_no {
//                // Check if the new string contains only digits
//                let allowedCharacters = CharacterSet.decimalDigits
//                let characterSet = CharacterSet(charactersIn: string)
//                if !allowedCharacters.isSuperset(of: characterSet) && !string.isEmpty {
//                    displayAlert(message: "Please enter digits only for phone number.")
//                    return false
//                }
//                
//                // Limit the length of the phone number to 10 digits
//                let currentText = textField.text ?? ""
//                guard let stringRange = Range(range, in: currentText) else { return false }
//                let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
//                if updatedText.count > 10 {
//                    displayAlert(message: "Phone number should be 10 digits long.")
//                    return false
//                }
//            }
//            return true
//        }
//    func saveAPI() {
//        guard let doctor = self.doctorDetails?.data.first else {
//            return
//        }
//        
//        let formData: [String: String] = [
//            "user_id": String(doctor.userID),
//            "Name": Name.text ?? "",
//            "phone_no": phone_no.text ?? "",
//            "email_id": email_id.text ?? "",
//            "institution": institution1.text ?? "",
//            "designation": designation.text ?? "",
//        ]
//        
//        APIHandler().postAPIValues(type: UpdateDcprofile.self, apiUrl: ServiceAPI.update_dc_profile_Url, method: "POST", formData: formData) { [weak self] result in
//            switch result {
//            case .success(let data):
//                print(data.message)
//                DispatchQueue.main.async {
//                    // Update the details on the previous page
//                    if let vc = self?.navigationController?.viewControllers.first as? view_profille {
////                        vc.doctor_details = self?.doctorDetails
////                        vc.getdetails() // Reload data
//                    }
//                    self?.navigationController?.popViewController(animated: true)
//                }
//            case .failure(let error):
//                print("Network Error: \(error)")
//                DispatchQueue.main.async {
//                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
//                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive))
//                    self?.present(alert, animated: true, completion: nil)
//                }
//            }
//        }
//    }
//    
//}
