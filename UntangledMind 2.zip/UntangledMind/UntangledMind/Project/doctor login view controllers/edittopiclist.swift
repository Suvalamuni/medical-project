import UIKit

class edittopiclist: UIViewController {
    var topiclist: Topics?
    var selectedTopicIndex: Int?
    
    @IBOutlet weak var topic_name: UITextField!
    @IBOutlet weak var topic_id: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        if let selectedTopicIndex = selectedTopicIndex {
            if let selectedTopic = topiclist?.data[selectedTopicIndex] {
                topic_name.text = selectedTopic.topicName
                topic_id.text = selectedTopic.topicID
            }
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func save(_ sender: Any) {
        saveAPI()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func updateTopic() {
        if let selectedTopicIndex = selectedTopicIndex,
           let currentTopics = topiclist {
            var updatedData = currentTopics.data
            let updatedTopic = topic(
                topicID: updatedData[selectedTopicIndex].topicID,
                topicName: self.topic_name.text ?? ""
            )
            
            updatedData[selectedTopicIndex] = updatedTopic
            
            let updatedTopics = Topics(success: currentTopics.success, data: updatedData)
            if let navController = self.navigationController {
                if let dTopicListVC = navController.viewControllers.first as? d_topiclist {
                    dTopicListVC.topiclist = updatedTopics
                    dTopicListVC.TABLE.reloadData()
                }
            }
        }
    }
    
    func saveAPI() {
        let formData: [String: String] = [
            "topic_id": topic_id.text ?? "",
            "topic_name": topic_name.text ?? "",
        ]
    
        print(formData, ServiceAPI.update_dc_profile_Url)
    
        APIHandler().postAPIValues(type: edittopics.self, apiUrl: ServiceAPI.edit_topiclistUrl, method: "POST", formData: formData) { [self] result in
            switch result {
            case .success(let data):
                print(data.message)
    
                DispatchQueue.main.async {
                    Utlis.showAlertWithCompletion(message: "Details updated successfully.", view: self) {
                        self.navigationController?.popViewController(animated: true)
                    }
                    
                }
    
            case .failure(let error):
                print("Network Error: \(error)")
    
                DispatchQueue.main.async {
                    Utlis.showAlert(title: "", message: "Something went wrong. Please try again.", view: self)
                }
            }
        }
    }

    
}
