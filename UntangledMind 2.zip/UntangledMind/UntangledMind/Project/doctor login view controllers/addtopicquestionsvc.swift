import UIKit

class addtopicquestionsvc: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var q1opt1: UITextField!
    @IBOutlet weak var q1opt2: UITextField!
    @IBOutlet weak var q1opt3: UITextField!
    @IBOutlet weak var q1opt4: UITextField!
    @IBOutlet weak var q2opt1: UITextField!
    @IBOutlet weak var q2opt2: UITextField!
    @IBOutlet weak var q2opt3: UITextField!
    @IBOutlet weak var q2opt4: UITextField!
    @IBOutlet weak var q3opt1: UITextField!
    @IBOutlet weak var q3opt2: UITextField!
    @IBOutlet weak var q3opt3: UITextField!
    @IBOutlet weak var q3opt4: UITextField!
    @IBOutlet weak var q4opt1: UITextField!
    @IBOutlet weak var q4opt2: UITextField!
    @IBOutlet weak var q4opt3: UITextField!
    @IBOutlet weak var q4opt4: UITextField!
    @IBOutlet weak var question1: UITextView!
    @IBOutlet weak var question2: UITextView!
    @IBOutlet weak var question3: UITextView!
    @IBOutlet weak var question4: UITextView!
    @IBOutlet weak var question4_id: UITextField!
    @IBOutlet weak var question3_id: UITextField!
    @IBOutlet weak var question2_id: UITextField!
    @IBOutlet weak var question1_id: UITextField!
    @IBOutlet weak var subtopic_name: UITextField!
    @IBOutlet weak var subtopic_id: UITextField!
    
    var questionTxtPlaceholder = "Enter the question..."
    var questionsData: [Question] = []
    var subtopicId: String = ""
    var subtopicName: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        subtopic_id.text = subtopicId
        subtopic_name.text = subtopicName
        question1.delegate = self
        question2.delegate = self
        question3.delegate = self
        question4.delegate = self
        question1.text = questionTxtPlaceholder
        question2.text = questionTxtPlaceholder
        question3.text = questionTxtPlaceholder
        question4.text = questionTxtPlaceholder
        
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        question1.text = ""
        question2.text = ""
        question3.text = ""
        question4.text = ""
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func onSubmit(_ sender: Any) {
      
            guard let subtopicId = subtopic_id.text,
                  let subtopicName = subtopic_name.text else {
                print("Subtopic ID or name is missing")
                return
            }
            
            createQuestionsData { questions in
                self.saveQuestionsAPI(subtopicId: subtopicId, subtopicName: subtopicName, questions: questions) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let response):
                            print("Success:", response.success)
                            print("Message:", response.message)
                            
                            // Show alert for success
                            let alert = UIAlertController(title: "Success", message: "Data added successfully.", preferredStyle: .alert)
                            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                                // Navigate to CaretakersListController
                                if let caretakersListController = self.storyboard?.instantiateViewController(withIdentifier: "CaretakersListController") {
                                    self.navigationController?.pushViewController(caretakersListController, animated: true)
                                }
                            }
                            alert.addAction(okAction)
                            self.present(alert, animated: true, completion: nil)
                            
                        case .failure(let error):
                            print("API Error:", error)
                            // Show alert for failure
                            let alert = UIAlertController(title: "Error", message: "Failed to add data. Please try again later.", preferredStyle: .alert)
                            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alert.addAction(okAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
            }
        }


    func saveQuestionsAPI(subtopicId: String, subtopicName: String, questions: [Question], completion: @escaping (Result<Addtopicquestions, Error>) -> Void) {
        let questionsDict = questions.map { question in
            return [
                "question_id": question.questionID,
                "question": question.question,
                "option_a": question.optionA,
                "option_b": question.optionB,
                "option_c": question.optionC,
                "option_d": question.optionD
            ]
        }
        
        let requestBody: [String: Any] = [
            "subtopic_id": subtopicId,
            "subtopic_name": subtopicName,
            "questions": questionsDict
        ]
        
        var jsonData: Data?
        do {
            jsonData = try JSONSerialization.data(withJSONObject: requestBody)
            let jsonObject = try JSONSerialization.jsonObject(with: jsonData!, options: [])
            guard let jsonDictionary = jsonObject as? [String: Any] else {
                print("Error: JSON data is not in the expected format")
                return
            }
            
            APIHandler().postAPIRawJSON(type: Addtopicquestions.self, apiUrl: ServiceAPI.addtopicquestionsUrl, method: "POST", jsonData: jsonDictionary) { result in
                switch result {
                case .success(let response):
                    completion(.success(response))
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        } catch {
            print("Error converting JSON data to dictionary: \(error)")
            completion(.failure(error))
        }
    }
}

extension addtopicquestionsvc {
    func createQuestionsData(completion: @escaping ([Question]) -> Void) {
        var questionsData: [Question] = []
        
        for i in 1...4 {
            let question = getQuestionText(for: i)
            let optionA = getOptionText(for: i, option: 1)
            let optionB = getOptionText(for: i, option: 2)
            let optionC = getOptionText(for: i, option: 3)
            let optionD = getOptionText(for: i, option: 4)
            
            let questionData = Question(questionID: "\(i)", question: question, optionA: optionA, optionB: optionB, optionC: optionC, optionD: optionD)
            questionsData.append(questionData)
        }
        
        completion(questionsData)
    }
    
    func getOptionText(for questionNumber: Int, option: Int) -> String {
        switch (questionNumber, option) {
        case (1, 1): return q1opt1.text ?? ""
        case (1, 2): return q1opt2.text ?? ""
        case (1, 3): return q1opt3.text ?? ""
        case (1, 4): return q1opt4.text ?? ""
        case (2, 1): return q2opt1.text ?? ""
        case (2, 2): return q2opt2.text ?? ""
        case (2, 3): return q2opt3.text ?? ""
        case (2, 4): return q2opt4.text ?? ""
        case (3, 1): return q3opt1.text ?? ""
        case (3, 2): return q3opt2.text ?? ""
        case (3, 3): return q3opt3.text ?? ""
        case (3, 4): return q3opt4.text ?? ""
        case (4, 1): return q4opt1.text ?? ""
        case (4, 2): return q4opt2.text ?? ""
        case (4, 3): return q4opt3.text ?? ""
        case (4, 4): return q4opt4.text ?? ""
        default: return ""
        }
    }
    
    func getQuestionText(for questionNumber: Int) -> String {
        switch questionNumber {
        case 1: return question1.text ?? ""
        case 2: return question2.text ?? ""
        case 3: return question3.text ?? ""
        case 4: return question4.text ?? ""
        default: return ""
        }
    }
}
