//
//  dayslist.swift
//  hi
//
//  Created by k. Dharani on 13/10/23.
//

import UIKit

class dayslist: UITableViewCell {

    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var day: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
