import UIKit

class edittopicques: UIViewController {
    @IBOutlet weak var ques_id: UILabel!
    @IBOutlet weak var opt1: UITextField!
    @IBOutlet weak var opt2: UITextField!
    @IBOutlet weak var opt3: UITextField!
    @IBOutlet weak var opt4: UITextField!
    @IBOutlet weak var question: UITextView!
    
    var selectedSubtopicId: String?
    var selectedQuestion: topicqns?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        if let selectedQuestion = selectedQuestion {
            ques_id.text = "\(selectedQuestion.questionID)"
            question.text = selectedQuestion.question
            opt1.text = selectedQuestion.optionA
            opt2.text = selectedQuestion.optionB
            opt3.text = selectedQuestion.optionC
            opt4.text = selectedQuestion.optionD
        }
    }

    @IBAction func save(_ sender: Any) {
        saveAPI()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func saveAPI() {
        guard let subtopicId = selectedSubtopicId else {
            print("Selected subtopic ID is nil")
            return
        }
        
        let formData: [String: String] = [
            "question_id": ques_id.text ?? "",
            "option_a": opt1.text ?? "",
            "option_b": opt2.text ?? "",
            "option_c": opt3.text ?? "",
            "option_d": opt4.text ?? "",
            "question": question.text ?? "",
            "subtopic_id": subtopicId 
        ]

        APIHandler().postAPIValues(type: EditQuestions.self, apiUrl: ServiceAPI.edit_topicquesUrl, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let data):
                print(data.message)
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }

            case .failure(let error):
                print("Network Error: \(error)")
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }

    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
