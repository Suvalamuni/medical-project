//
//  edit_subtopics.swift
//  UntangledMind
//
//  Created by k. Dharani on 31/01/24.
//

import UIKit

class edit_subtopics: UIViewController {
    var subtopiclist: Subtopics?
    var selectedsubTopicIndex: Int?
    @IBOutlet weak var subtopic_id: UILabel!
    @IBOutlet weak var subtopic_name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        if let selectedsubTopicIndex = selectedsubTopicIndex {
            if let selectedsubTopic = subtopiclist?.data[selectedsubTopicIndex] {
                subtopic_name.text = selectedsubTopic.subtopicName
                subtopic_id.text = selectedsubTopic.subtopicId
            }
            
        }
    }
    
    @IBAction func onback(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func save(_ sender: Any) {
        saveAPI()
        updatesubTopic()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func updatesubTopic() {
        if let selectedsubTopicIndex = selectedsubTopicIndex,
           let currentTopics = subtopiclist {
            var updatedData = currentTopics.data
            
            let updatedsubTopic = SubtopicData(
                topicName: updatedData[selectedsubTopicIndex].topicName,
                subtopicId: updatedData[selectedsubTopicIndex].subtopicId,
                subtopicName: subtopic_name.text ?? ""
            )
            
            
            updatedData[selectedsubTopicIndex] = updatedsubTopic
            
            
            let updatedSubtopics = Subtopics(status: currentTopics.status, data: updatedData)
            if let navController = self.navigationController {
                if let dsubTopicListVC = navController.viewControllers.first as? d_subtopicsViewController {
                    dsubTopicListVC.subtopiclist = updatedSubtopics
                    dsubTopicListVC.table.reloadData()
                }
            }
            
        }
    }
   
    func saveAPI() {
        let formData: [String: String] = [
            "subtopic_id": subtopic_id.text ?? "",
            "subtopic_name": subtopic_name.text ?? "",
        ]
        
        print(formData, ServiceAPI.update_dc_profile_Url)
        
        APIHandler().postAPIValues(type: editSubtopics.self, apiUrl: ServiceAPI.edit_subtopicslistUrl, method: "POST", formData: formData) { [self] result in
            switch result {
            case .success(let data):
                print(data.message)
                DispatchQueue.main.async {
                    // Show success alert
                    self.showAlert(title: "Success", message: "Details updated successfully.") {
                        // Navigate to the previous view controller after dismissing the alert
                        self.navigationController?.popViewController(animated: true)
                    }
                }
                
            case .failure(let error):
                print("Network Error: \(error)")
                DispatchQueue.main.async {
                    // Show error alert
                    self.showAlert(title: "Warning", message: "Something went wrong. Please try again.")
                }
            }
        }
    }

    func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in
            completion?()
        }))
        self.present(alert, animated: true, completion: nil)
    }

}
