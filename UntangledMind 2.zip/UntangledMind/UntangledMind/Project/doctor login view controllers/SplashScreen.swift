//
//  SplashScreen.swift
//  hi
//
//  Created by k. Dharani on 11/10/23.
//

import UIKit

class SplashScreen: UIViewController {

    @IBOutlet weak var getstarted: UIButton!
    @IBOutlet weak var tap: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        getstarted.layer.cornerRadius=5
        getstarted.clipsToBounds=true
//        CaretakerLogin.layer.cornerRadius=30
//        CaretakerLogin.clipsToBounds=true
    }
    

    @IBAction func ontap(_ sender: Any) {
        
        
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "ViewController")
        as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
