import UIKit
import AVKit
import AVFoundation

class d_videos: UIViewController, AVPlayerViewControllerDelegate {
    
    @IBOutlet weak var subtopicname: UILabel!
    @IBOutlet weak var video: UIView!
    @IBOutlet weak var descrip: UILabel!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    var player: AVPlayer?
    var playerViewController: AVPlayerViewController?
    var selectedSubTopicId = String()
    var selectedSubTopic = String()
    var videoUrls = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        //                self.view.addGestureRecognizer(tapGesture)
        
        // Show loader initially
        loader.startAnimating()
        
        fetchVideoData()
        subtopicname.text = selectedSubTopic
    }
    //    @objc func dismissKeyboard() {
    //            view.endEditing(true)
    //        }
    func fetchVideoData() {
        APIHandler().getAPIValues(type: GetVideo.self, apiUrl: ServiceAPI.get_video_Url + "?subtopic_name=\(selectedSubTopic)", method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print("Received data from server: \(data)")
                
                DispatchQueue.main.async {
                    // Construct the complete video URL by appending ServiceAPI.baseUrl
                    let completeVideoURL = ServiceAPI.baseUrl + data.videoURL
                    self?.playVideo(with: completeVideoURL)
                    self?.descrip.text = data.description
                    self?.videoUrls = completeVideoURL
                }
                
            case .failure(let error):
                print("API Request Error: \(error)")
                // Hide loader on failure
                self?.loader.stopAnimating()
            }
        }
    }
    
    @IBAction func editbtn(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "Edit_videos") as! Edit_videos
        vc.videoDescription = descrip.text ?? ""
        vc.selectedVideoURL = URL(string: videoUrls)
        vc.selectedSubTopicId = self.selectedSubTopicId
        vc.selectedSubTopic = subtopicname.text ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func onques(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "d_topicques") as! d_topicques
        vc.selectedSubTopicId = selectedSubTopicId
        vc.selectedSubTopic = selectedSubTopic
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func baack(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
    
    //    func playVideo(with url: String) {
    //        guard let videoURL = URL(string: url) else {
    //            print("Invalid video URL")
    //            return
    //        }
    //
    //        let asset = AVAsset(url: videoURL)
    //        let playerItem = AVPlayerItem(asset: asset)
    //
    //        player = AVPlayer(playerItem: playerItem)
    //
    //        guard let player = player else {
    //            print("Failed to initialize AVPlayer")
    //            return
    //        }
    //
    //        playerViewController = AVPlayerViewController()
    //        playerViewController?.player = player
    //        playerViewController?.entersFullScreenWhenPlaybackBegins = false
    //        playerViewController?.allowsPictureInPicturePlayback = false
    //
    //        addChild(playerViewController!)
    //        playerView.addSubview(playerViewController!.view)
    //        playerViewController?.view.frame = playerView.bounds
    //        playerViewController?.didMove(toParent: self)
    //
    //        // Add observer for player status
    //        player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context: nil)
    //
    //        player.play()
    //
    //        // Hide loader once video starts playing
    //        loader.stopAnimating()
    //    }
    //
    //    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    //        if keyPath == #keyPath(AVPlayer.status) {
    //            if let player = player {
    //                if player.status == .failed {
    //                    if let error = player.error {
    //                        print("Failed to load video: \(error)")
    //                    } else {
    //                        print("Failed to load video with an unknown error.")
    //                    }
    //                    // Hide loader on failure
    //                    loader.stopAnimating()
    //                } else if player.status == .readyToPlay {
    //                    // Hide loader once video is ready to play
    //                    loader.stopAnimating()
    //                }
    //            } else {
    //                print("AVPlayer is nil.")
    //            }
    //        }
    //    }
    //}
    func playVideo(with url: String) {
        guard let videoURL = URL(string: url) else {
            //print("Invalid video URL")
            return
        }
        
        player = AVPlayer(url: videoURL)
        
        guard let player = player else {
            //  print("Failed to initialize AVPlayer")
            return
        }
        
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        playerViewController.entersFullScreenWhenPlaybackBegins = false
        playerViewController.allowsPictureInPicturePlayback = false
        
        addChild(playerViewController)
        playerView.addSubview(playerViewController.view)
        playerViewController.view.frame = playerView.bounds
        playerViewController.didMove(toParent: self)
        
        // Add observer for player status
        player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context: nil)
    }
    
    // Implement key-value observation method
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == #keyPath(AVPlayer.status) {
            if let player = player {
                if player.status == .failed {
                    if let error = player.error {
                        // print("Failed to load video: \(error)")
                    } else {
                        //print("Failed to load video with an unknown error.")
                    }
                }
            } else {
                // print("AVPlayer is nil.")
            }
        }
    }
}
