//
//  d_topicquestvc.swift
//  UntangledMind
//
//  Created by k. Dharani on 30/01/24.
//

import UIKit

class d_topicquestvc: UITableViewCell {

    

        @IBOutlet weak var ques_id: UILabel!
        @IBOutlet weak var questiontext: UILabel!
        @IBOutlet weak var op1: UILabel!
        @IBOutlet weak var op2: UILabel!
        @IBOutlet weak var op3: UILabel!
        @IBOutlet weak var op4: UILabel!
        
    @IBOutlet weak var edit: UIButton!
    
        var selectNum:((Int) ->())?
    var questionID: Int = 0
        
        override func awakeFromNib() {
            super.awakeFromNib()
            
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)

            
        }
        
    @IBAction func onedit(_ sender: Any) {
        selectNum?(questionID)
    }
}

