import UIKit

class view_profille: UIViewController {
    
    
    @IBOutlet weak var passwordLabel: UITextField!
    @IBOutlet weak var useridLabel: UITextField!
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var genderLabel: UITextField!
    @IBOutlet weak var phonenoLabel: UITextField!
    @IBOutlet weak var institutionLabel: UITextField!
    @IBOutlet weak var designationLabel: UITextField!
    @IBOutlet weak var ageLabel: UITextField!
    @IBOutlet weak var doctorimage: UIImageView!
    var selectedUserID: String = ""
    var doctordetail: docdetails?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.selectedUserID = DoctorManager.shared.doctorID!
        print(selectedUserID)
        useridLabel.isUserInteractionEnabled = false
            nameLabel.isUserInteractionEnabled = false
            ageLabel.isUserInteractionEnabled = false
            genderLabel.isUserInteractionEnabled = false
            phonenoLabel.isUserInteractionEnabled = false
            passwordLabel.isUserInteractionEnabled = false
            institutionLabel.isUserInteractionEnabled = false
            designationLabel.isUserInteractionEnabled = false
            emailLabel.isUserInteractionEnabled = false
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
       
        fetchDoctorDetails()
    }
    @IBAction func editbtn(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "editdoctor_vc")
        as! editdoctor_vc
        vc.doctorDetail = doctordetail
        vc.doctorImageURL = doctordetail?.doctorimage
      
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func onback(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func onlogout(_ sender: Any) {
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "SplashScreen")
                as! SplashScreen
            self.navigationController?.pushViewController(vc, animated: true)
        }
    func fetchDoctorDetails() {
        guard let userId = selectedUserID.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("User ID is nil")
            return
        }
        let apiUrl = "\(ServiceAPI.doctordetailsUrl)?user_id=\(userId)"
        print(userId)
        
        APIHandler().getAPIValues(type: docdetails.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let DoctorDetail):
                DispatchQueue.main.async {
                    self?.doctordetail = DoctorDetail
                    if let urlString = self?.doctordetail?.doctorimage,
                       let url = URL(string: ServiceAPI.baseUrl + urlString) {
                        URLSession.shared.dataTask(with: url) { (data, response, error) in
                            if let data = data, let image = UIImage(data: data) {
                                DispatchQueue.main.async {
                                    self?.doctorimage.image = image
                                }
                            }
                        }.resume()
                    }
                    
                    self?.useridLabel.text = DoctorDetail.userID
                    self?.nameLabel.text = DoctorDetail.name
                    self?.ageLabel.text = "\(DoctorDetail.age)"
                    self?.genderLabel.text = DoctorDetail.gender
                    self?.phonenoLabel.text = DoctorDetail.phoneNo
                    self?.passwordLabel.text = DoctorDetail.password
                    self?.institutionLabel.text = DoctorDetail.institution
                    self?.designationLabel.text = DoctorDetail.designation
                    self?.emailLabel.text = DoctorDetail.emailID
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }

}

//
//    @IBOutlet weak var age: UITextField!
//    @IBOutlet weak var password: UITextField!
//    @IBOutlet weak var user_id: UITextField!
//    @IBOutlet weak var Name: UITextField!
//    @IBOutlet weak var email_id: UITextField!
//    @IBOutlet weak var back: UIButton!
//    @IBOutlet weak var phone_no: UITextField!
//    @IBOutlet weak var designation: UITextField!
//    @IBOutlet weak var logout: UIButton!
//    @IBOutlet weak var institution: UITextField!
//    @IBOutlet weak var gender: UITextField!
//    
//    var doctor_details: DoctorProfile?
//    var userId: String = ""
//    let loaderView = loader()
//
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        user_id.isUserInteractionEnabled = false
//            Name.isUserInteractionEnabled = false
//            age.isUserInteractionEnabled = false
//            gender.isUserInteractionEnabled = false
//            phone_no.isUserInteractionEnabled = false
//            password.isUserInteractionEnabled = false
//            institution.isUserInteractionEnabled = false
//            designation.isUserInteractionEnabled = false
//            email_id.isUserInteractionEnabled = false
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
//       
//    }
//   
//
//    override func viewWillAppear(_ animated: Bool) {
//            super.viewWillAppear(animated)
//        if let doctorID = DoctorManager.shared.doctorID {
//                   print("Doctor ID: \(doctorID)")
//               } else {
//                   print("Doctor ID is not available.")
//               }
//            getdetails()
//        }
//    @IBAction func onback(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//    }
//    @objc func dismissKeyboard() {
//            view.endEditing(true)
//        }
//    @IBAction func onlogout(_ sender: Any) {
//       // UserDefaultsManager.shared.setLogin(bool: false)
//        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//        let vc=storyBoard.instantiateViewController(identifier: "SplashScreen")
//            as! SplashScreen
//        self.navigationController?.pushViewController(vc, animated: true)
//    }
//
//    @IBAction func Edit(_ sender: Any) {
//        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//           let vc=storyBoard.instantiateViewController(identifier: "edit_profile") as! edit_profile
//        vc.doctorDetails = self.doctor_details
//           self.navigationController?.pushViewController(vc, animated: true)
//       }
//    func getdetails() {
////        showLoader()
//        guard userId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) != nil else {
//            print("User ID is nil")
//            return
//        }
//        let apiUrl = ServiceAPI.Doctor_profile_Url
//
//        APIHandler().getAPIValues(type: DoctorProfile.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
//            switch result {
//            case .success(let doctordetails):
//                DispatchQueue.main.async {
//                    self?.doctor_details = doctordetails
//                    if let userID = self?.doctor_details?.data.first?.userID {
//                        self?.user_id.text = String(userID)
//                    }
//                    if let name = self?.doctor_details?.data.first?.name {
//                        self?.Name.text = String(name)
//                    }
//                    if let password = self?.doctor_details?.data.first?.password {
//                        self?.password.text = String(password)
//                    }
//                    if let email = self?.doctor_details?.data.first?.emailID {
//                        self?.email_id.text = String(email)
//                    }
//                    
//                    if let age = self?.doctor_details?.data.first?.institution {
//                        self?.age.text = String(age)
//                    }
//
//                    if let phone = self?.doctor_details?.data.first?.phoneNo {
//                        UserDefaults.standard.setValue(phone, forKey: "DoctorPhone")
//                        self?.phone_no.text = String(phone)
//                        
//                    }
//
//                    if let institution = self?.doctor_details?.data.first?.institution {
//                        self?.institution.text = String(institution)
//                    }
//
//                    if let designation = self?.doctor_details?.data.first?.designation {
//                        self?.designation.text = String(designation)
////                        self?.hideLoader()
//
//                    }
//                }
//            case .failure(let error):
//                print("API request failed with error: \(error)")
////                self?.hideLoader()
//            }
//        }
//    }
////    func showLoader() {
////            loaderView.frame = view.bounds
////            view.addSubview(loaderView)
////            loaderView.startAnimating()
////        }
////        
////        // Method to hide the loader
////        func hideLoader() {
////            loaderView.stopAnimating()
////            loaderView.removeFromSuperview()
////        }
//}
