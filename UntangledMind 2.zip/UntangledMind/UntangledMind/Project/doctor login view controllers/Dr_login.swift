import UIKit

class Dr_login: UIViewController {

    @IBOutlet weak var signup: UIButton!
    @IBOutlet weak var User_id: UITextField!
    
    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var phone_no: UITextField!
    @IBOutlet weak var email_id: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var Re_enter_password: UITextField!
    @IBOutlet weak var designation: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        
    }

    @IBAction func onsignup(_ sender: Any) {
        if Name.text == "" ||  phone_no.text == "" || email_id.text == "" || password.text == "" || Re_enter_password.text == "" || designation.text == "" || User_id.text == ""  {
            // Handle case when any field is empty
            print("All fields are required.")
        } else {
            
            registerUser()
        }
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }

    func registerUser() {
        let apiURL = ServiceAPI.signupUrl
        print("API URL:", apiURL)
        let formData: [String: String] = [
            "user_id": User_id.text ?? "",
            "Name": Name.text ?? "",
            "phone_no": phone_no.text ?? "",
            "email_id": email_id.text ?? "",
            "password": password.text ?? "",
            "Re_enter_password": Re_enter_password.text ?? "",
            "designation": designation.text ?? "",
        ]

        APIHandler().postAPIValues(type: signup_model.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            print("Result---->",result)

            switch result {
            case .success(let response) :
                
                
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                
                DispatchQueue.main.async {
                    if response.status == "success" {
                        // Handle successful registration
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(identifier: "doctor_login_vc") as! doctor_login_vc
                        self.navigationController?.pushViewController(vc, animated: true)
                    } else {
                        // Handle error scenarios
                        // Display appropriate messages or take corrective actions
                        print("Error: \(response.message)")
                    }
                }
             
            case .failure(let error) :
                print("API Error:", error)

                DispatchQueue.main.async {
                    // Display an alert or take corrective actions
                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                        print("JSON Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}
