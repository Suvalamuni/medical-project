//
//  ViewController.swift
//  hi
//
//  Created by k. Dharani on 27/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DoctorLogin: UIButton!
    
    @IBOutlet weak var CaretakerLogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func onDoctor(_ sender: Any) {
        
        let isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")

        // Using the retrieved boolean value
        if isLoggedIn {
           
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "CaretakersListController")
            as! CaretakersListController
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "doctor_login_vc")
            as! doctor_login_vc
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
       
    }
    

    @IBAction func oncaretaker(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "caretakerlogin")
        as! caretakerlogin
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Admin(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "adminloginvc")
        as! adminloginvc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func onback(_ sender: Any) {
    }
}
