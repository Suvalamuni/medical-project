//
//  d_subtopicsViewController.swift
//  UntangledMind
//
//  Created by k. Dharani on 30/01/24.
//

import UIKit

class d_subtopicsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var subtopiclist: Subtopics?
    
    
    @IBOutlet weak var topicname: UILabel!
    @IBOutlet weak var table: UITableView!
    
    var selectedTopicName: String?
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "dsubtopic_TVC", bundle: nil), forCellReuseIdentifier: "dsubtopic_TVC")
        if let selectedTopic = selectedTopicName {
            topicname.text = selectedTopic
        }
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
       
        fetchData()
        }

//    @objc func dismissKeyboard() {
//            view.endEditing(true)
//        }
    func fetchData() {
        
        APIHandler().getAPIValues(type: Subtopics.self, apiUrl:ServiceAPI.getsubtopicUrl+"?topic_name=\(selectedTopicName ?? "")" , method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.subtopiclist = data
                    self?.table.reloadData()
                }
            case .failure(let error):
                print("API Request Error: \(error)")
            }
        }
    }
        
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return subtopiclist?.data.count ?? 0
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(identifier: "d_videos") as! d_videos
            vc.selectedSubTopicId = subtopiclist?.data[indexPath.row].subtopicId ?? ""

            vc.selectedSubTopic =  subtopiclist?.data[indexPath.row].subtopicName ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "dsubtopic_TVC", for: indexPath) as! dsubtopic_TVC
            
            if let subtopic = subtopiclist?.data[indexPath.row] {
                cell.subtopic_name.text = subtopic.subtopicName
                cell.subtopic_id.text = subtopic.subtopicId
                
                cell.editButton.tag = indexPath.row
                cell.editButton.addTarget(self, action: #selector(editButtonTapped(_:)), for: .touchUpInside)
            }
            
            
            return cell
        }
    
    
    @objc func editButtonTapped(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let editVC = storyBoard.instantiateViewController(identifier: "edit_subtopics") as! edit_subtopics
        
    
        editVC.subtopiclist = subtopiclist
        editVC.selectedsubTopicIndex = sender.tag
        
        self.navigationController?.pushViewController(editVC, animated: true)
    }

        @IBAction func back(_ sender: Any) {
            self.navigationController?.popViewController(animated:true)
        }
        
        
    }
