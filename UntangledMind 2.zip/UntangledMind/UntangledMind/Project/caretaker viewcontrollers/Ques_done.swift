//
//  Ques_done.swift
//  hi
//
//  Created by k. Dharani on 14/10/23.
//

import UIKit

class Ques_done: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


    @IBAction func next(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "Caretaker_hm")
        as! Caretaker_hm
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
