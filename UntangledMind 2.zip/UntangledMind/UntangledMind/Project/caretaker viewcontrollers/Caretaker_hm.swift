
import UIKit


class Caretaker_hm: UIViewController, UITableViewDelegate, UITableViewDataSource
{

    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var alertLabel: UILabel!
    @IBOutlet weak var pgcontrol: UIPageControl!
    @IBOutlet weak var collection_view: UICollectionView!
    @IBOutlet weak var table: UITableView!
    
    var currentcellIndex = 0
    var motivationImages = ["img1 ","img2 ","img3","img4","img5"]
    let loaderView = loader()
    var infiniteImages: [String]!
    var timer: Timer?
    var userId: String = ""
    var suggestions: GetSuggestions?
    var ctname: Caretakernamemodel?
    var phno: Phonenumbermodel?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        getdetails()
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "caretakerhm_TVCTableViewCell", bundle: nil), forCellReuseIdentifier: "caretakerhm_TVCTableViewCell")
        view.addSubview(loaderView)
                loaderView.frame = view.bounds
                loaderView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        setupNoSuggestionsLabel()
        
        infiniteImages = Array(repeating: motivationImages, count: 1000).flatMap { $0 }
        
        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(slideToNext), userInfo: nil, repeats: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
        fetchData()
        loaderView.startAnimating()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @objc func slideToNext() {
        guard motivationImages.count > 0 else {
            return
        }

        let newIndex = (currentcellIndex + 1) % infiniteImages.count
        pgcontrol.currentPage = newIndex % motivationImages.count
        collection_view.scrollToItem(at: IndexPath(item: newIndex, section: 0), at: .right, animated: true)
        currentcellIndex = newIndex
    }
    
    @IBAction func TEST(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "Questionaries")
        as! Questionaries
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func whatsbtn(_ sender: Any) {
        let phoneNumber = "1234567890" 
        let doctorPhoneNumber = UserDefaults.standard.string(forKey: "DoctorPhone")
        if let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(String(describing: doctorPhoneNumber))") {
            if UIApplication.shared.canOpenURL(whatsappURL) {
                UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
            } else {
                
                let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
            }
        }
    }
    func setupNoSuggestionsLabel() {
        alertLabel.text = "No suggestions found"
        alertLabel.textColor = .black
        alertLabel.textAlignment = .center
        alertLabel.numberOfLines = 0
        
    }
    func getphno() {
       

        let apiUrl = "\(ServiceAPI.doctorphoneUrl)?user_id=\(DoctorManager.shared.doctorID ?? "0")"
        print(apiUrl)

        APIHandler().getAPIValues(type: Phonenumbermodel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let doctName):
                DispatchQueue.main.async {
                    self?.phno = doctName
                    //self?.namelbl.text = doctName.data.first?.name
                    
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    func getdetails() {
       

        let apiUrl = "\(ServiceAPI.caretaker_nameUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
        print(apiUrl)

        APIHandler().getAPIValues(type: Caretakernamemodel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let doctName):
                DispatchQueue.main.async {
                    self?.ctname = doctName
                    self?.namelbl.text = doctName.data.first?.name
                    
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    
    func fetchData() {
        let apiUrl = "\(ServiceAPI.get_suggestionUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
//        print(apiUrl)
        APIHandler().getAPIValues(type: GetSuggestions.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.suggestions = data
                    self?.table.reloadData()
                    self?.alertLabel.isHidden = !(self?.suggestions?.data.isEmpty ?? true)
                                    self?.table.isHidden = (self?.suggestions?.data.isEmpty ?? true)
                                    self?.loaderView.stopAnimating()


                }
            case .failure(let error):
                print("API Request Error: \(error)")
                DispatchQueue.main.async {
                    self?.loaderView.stopAnimating()
                    self?.alertLabel.isHidden = false
                }
            }
        }
    }
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return suggestions?.data.count ?? 0
    }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "caretakerhm_TVCTableViewCell", for: indexPath) as! caretakerhm_TVCTableViewCell
        
        let suggestionslist = suggestions?.data[indexPath.row]
        cell.datelbl.text = suggestionslist?.date
        cell.suggestionlbl.text = suggestionslist?.suggestion
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }

    @IBAction func onviewall(_ sender: Any) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "suggestionsvc") as! suggestionsvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
        
    
    
    @IBAction func watch_videos(_ sender: Any) {

        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Topics_list") as! Topics_list
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func profile(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "CT_profile")
        as! CT_profile
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension Caretaker_hm: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return infiniteImages.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collection_view.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CV_cell
            cell.motivationimg.image = UIImage(named: infiniteImages[indexPath.row])
            return cell
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: collection_view.frame.width, height: collection_view.frame.height)
        }
        
    }
    
    
   

       
       
    

