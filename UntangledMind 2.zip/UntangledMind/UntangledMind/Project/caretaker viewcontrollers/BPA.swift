import UIKit
import AVKit
import AVFoundation

class BPA: UIViewController, AVPlayerViewControllerDelegate {
    
    @IBOutlet weak var subtopicname: UILabel!
    @IBOutlet weak var video: UIView!
    @IBOutlet weak var descrip: UILabel!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var player: AVPlayer?
        var selectedSubTopic = ""
        var videoUrls = ""
        
        override func viewDidLoad() {
            super.viewDidLoad()
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            self.view.addGestureRecognizer(tapGesture)
            // Initialize and start activity indicator
            activityIndicator.style = .large
            activityIndicator.startAnimating()
            subtopicname.text = selectedSubTopic
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            fetchVideoData()
        }
        
        func fetchVideoData() {
            APIHandler().getAPIValues(type: GetVideo.self, apiUrl: ServiceAPI.get_video_Url + "?subtopic_name=\(selectedSubTopic)", method: "GET") { [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        // Construct the complete video URL by appending baseUrl
                        let completeVideoURL = ServiceAPI.baseUrl + data.videoURL
                        print("Complete Video URL: \(completeVideoURL)") // Print the complete video URL for debugging
                        self?.playVideo(with: completeVideoURL)
                        self?.descrip.text = data.description
                        self?.videoUrls = completeVideoURL
                        self?.activityIndicator.stopAnimating()
                    }
                    
                case .failure(let error):
                    print("API Request Error: \(error)")
                    // Stop activity indicator in case of failure
                    DispatchQueue.main.async {
                        self?.activityIndicator.stopAnimating()
                    }
                }
            }
        }
        
        @objc func dismissKeyboard() {
            view.endEditing(true)
        }
        
        @IBAction func ontest(_ sender: Any) {
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "testvc") as! testvc
            vc.selectedSubTopic = self.selectedSubTopic
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        @IBAction func baack(_ sender: Any) {
            self.navigationController?.popViewController(animated:true)
        }
        
        func playVideo(with url: String) {
            guard let videoURL = URL(string: url) else {
                //print("Invalid video URL")
                return
            }
            
            player = AVPlayer(url: videoURL)
            
            guard let player = player else {
                //  print("Failed to initialize AVPlayer")
                return
            }
            
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            playerViewController.entersFullScreenWhenPlaybackBegins = false
            playerViewController.allowsPictureInPicturePlayback = false
            
            addChild(playerViewController)
            playerView.addSubview(playerViewController.view)
            playerViewController.view.frame = playerView.bounds
            playerViewController.didMove(toParent: self)
            
            // Add observer for player status
            player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context: nil)
        }
        
        // Implement key-value observation method
        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
            if keyPath == #keyPath(AVPlayer.status) {
                if let player = player {
                    if player.status == .failed {
                        if let error = player.error {
                            // print("Failed to load video: \(error)")
                        } else {
                            //print("Failed to load video with an unknown error.")
                        }
                    }
                } else {
                    // print("AVPlayer is nil.")
                }
            }
        }
    }
