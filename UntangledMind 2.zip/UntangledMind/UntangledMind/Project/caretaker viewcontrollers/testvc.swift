import UIKit

class testvc: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var nextbtn: UIButton!
    @IBOutlet weak var previousbtn: UIButton!
    @IBOutlet weak var testcell: UITableView!
    var qnsAnsData: gettopicqns?
    var currentQuestionIndex : Int = 0
    var selectedSubTopic = String()
    
    
    var firstAnswer = String()
    var secAnswer = String()
    var thirdAnswer = String()
    var FourthAnswer = String()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        //GetQnsAnsList()
        currentQuestionIndex = 0
        
        testcell.register(UINib(nibName: "test_tvc", bundle: nil), forCellReuseIdentifier: "testCellReuseIdentifier")
        testcell.dataSource = self
        testcell.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        GetQnsAnsList()
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
    
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func previousbtn(_ sender: Any) {
        
        
        if currentQuestionIndex != 0 {
            currentQuestionIndex = currentQuestionIndex - 1
            testcell.reloadData()
        }
        
    }
    
    @IBAction func nextBtn(_ sender: Any) {
//        
//        print("1======>\(firstAnswer)")
//        print("2======>\(secAnswer)")
//        print("3======>\(thirdAnswer)")
//        print("4======>\(FourthAnswer)")
//        currentQuestionIndex = currentQuestionIndex + 1
//        if currentQuestionIndex > 3 {
//            
//            currentQuestionIndex = 0
//            
//            popUpAlert(title: "Message", message: "Are you sure to Submit", actionTitles: ["OK","Cancel"], actionStyle: [.default,.default], action: [{ Ok in
//                self.sentAllAnswer { success in
//                    if success {
//                        // Navigate to Topics_list screen
//                        self.navigateToTopicsList()
//                    } else {
//                        print("Failed to submit answers")
//                    }
//                }
//            }, { Cancel in
//                print("Submit Dismiss")
//                self.dismiss(animated: true)
//            }])
//        }
//        
//        testcell.reloadData()
//    }
//    
//    func sentAllAnswer(completion: @escaping (Bool) -> Void) {
//        let formData: [String: String] = [
//            "user_id": DoctorManager.shared.caretakerID ?? "",
//            "subtopic_name":selectedSubTopic,
//            "question1":"1",
//            "answer1":firstAnswer,
//            "question2":"2",
//            "answer2":secAnswer,
//            "question3":"3",
//            "answer3":thirdAnswer,
//            "question4":"4",
//            "answer4": FourthAnswer,
//        ]
//        
//        APIHandler().postAPIValues(type: SentQuestion.self, apiUrl: ServiceAPI.topicAnswerUrl, method: "POST", formData: formData) { result in
//            print("Result---->",result)
//            
//            switch result {
//            case .success(let response) :
//                DispatchQueue.main.async {
//                    if response.status == true {
//                        let alertController = UIAlertController(title: "Message", message: response.message, preferredStyle: .alert)
//                        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
//                            // Return success through completion handler
//                            completion(true)
//                        }
//                        alertController.addAction(okAction)
//                        self.present(alertController, animated: true, completion: nil)
//                    } else {
//                        print("Error: \(response.message)")
//                        // Return failure through completion handler
//                        completion(false)
//                    }
//                }
//            case .failure(let error) :
//                print("API Error:", error)
//                
//                DispatchQueue.main.async {
//                    // Display an alert or take corrective actions
//                    let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
//                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
//                        print("JSON Error")
//                    })
//                    self.present(alert, animated: true, completion: nil)
//                    // Return failure through completion handler
//                    completion(false)
//                }
//            }
//        }
//    }
//    
//    func navigateToTopicsList() {
//        if let navigationController = self.navigationController {
//            for controller in navigationController.viewControllers as Array {
//                if controller.isKind(of: Topics_list.self) {
//                    navigationController.popToViewController(controller, animated: true)
//                    break
//                }
//            }
//        } else {
//            print("Navigation controller is nil")
//        }
//    }
    
            print("1======>\(firstAnswer)")
            print("2======>\(secAnswer)")
            print("3======>\(thirdAnswer)")
            print("4======>\(FourthAnswer)")
            currentQuestionIndex = currentQuestionIndex + 1
            if currentQuestionIndex > 3 {
    
                currentQuestionIndex = 0
    
                popUpAlert(title: "Message", message: "Are you sure to Submit", actionTitles: ["OK","Cancel"], actionStyle: [.default,.default], action: [{ Ok in
                    self.sentAllAnwer()
                }, { Cancel in
                    print("Submit Dismiss")
                    self.dismiss(animated: true)
                }])
            }
    
            testcell.reloadData()
        }
    
    
    
    
    
        func GetQnsAnsList() {
            APIHandler().getAPIValues(type: gettopicqns.self, apiUrl: ServiceAPI.videoQuestionaryUrl+"?subtopic_name=\(selectedSubTopic)", method: "GET") { result in
                switch result {
                case .failure(let error):
                    print(error)
                case .success(let data):
                    self.qnsAnsData = data
                    DispatchQueue.main.async {
                        self.testcell.reloadData()
    
                    }
                }
            }
        }
    
    
    
    
        func sentAllAnwer() {
            let formData: [String: String] = [
                "user_id": DoctorManager.shared.caretakerID ?? "",
                "subtopic_name":selectedSubTopic,
                "question1":"1",
                "answer1":firstAnswer,
                "question2":"2",
                "answer2":secAnswer,
                "question3":"3",
                "answer3":thirdAnswer,
                "question4":"4",
                "answer4": FourthAnswer,
            ]
    
            APIHandler().postAPIValues(type: SentQuestion.self, apiUrl: ServiceAPI.topicAnswerUrl, method: "POST", formData: formData) { result in
                print("Result---->",result)
    
                switch result {
                case .success(let response) :
                    DispatchQueue.main.async {
                        if response.status == true {
                            let alertController = UIAlertController(title: "Message", message: response.message, preferredStyle: .alert)
                            let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
                                self.navigateToPreviousPage()
                            }
                            alertController.addAction(okAction)
                            self.present(alertController, animated: true, completion: nil)
                        } else {
                            print("Error: \(response.message)")
                        }
                    }
                case .failure(let error) :
                    print("API Error:", error)
    
                    DispatchQueue.main.async {
                        // Display an alert or take corrective actions
                        let alert = UIAlertController(title: "OOPS", message: "Something Went Wrong", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                            print("JSON Error")
                        })
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    
        func navigateToPreviousPage() {
            // Check if self.navigationController is not nil
            if let navigationController = self.navigationController {
                // Use optional binding to safely unwrap the navigationController
                for controller in navigationController.viewControllers as Array {
                    if controller.isKind(of: Topics_list.self) {
                        // If found the desired view controller, pop to it
                        navigationController.popToViewController(controller, animated: true)
                        break
                    }
                }
            } else {
                print("Navigation controller is nil")
            }
        }
    }


    extension testvc {
        
     
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in your data source
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "testCellReuseIdentifier", for: indexPath) as! test_tvc
        cell.opt1.setImage(UIImage(named: "unSelect"), for: .normal)
        cell.opt2.setImage(UIImage(named: "unSelect"), for: .normal)
        cell.opt3.setImage(UIImage(named: "unSelect"), for: .normal)
        cell.opt4.setImage(UIImage(named: "unSelect"), for: .normal)
        if let qnsAnsData = qnsAnsData?.data[currentQuestionIndex] {
            cell.questiontext.text = qnsAnsData.question
            cell.ques_id.text = "\(qnsAnsData.questionID)"
            cell.op1.text = qnsAnsData.optionA
            cell.op2.text = qnsAnsData.optionB
            cell.op3.text = qnsAnsData.optionC
            cell.op4.text = qnsAnsData.optionD
        }
       
        cell.selectNum = {  num in
            if self.currentQuestionIndex == 0 {
                switch num {
                case 0:
                    self.firstAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionA ?? ""
                case 1:
                    self.firstAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionB ?? ""
                case 2:
                    self.firstAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionC ?? ""
                case 3:
                    self.firstAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionD ?? ""
                default:
                    print("")
                }
            }
            else if self.currentQuestionIndex == 1 {
                switch num {
                case 0:
                    self.secAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionA ?? ""
                case 1:
                    self.secAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionB ?? ""
                case 2:
                    self.secAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionC ?? ""
                case 3:
                    self.secAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionD ?? ""
                default:
                    print("")
                }
            }
            else if self.currentQuestionIndex == 2 {
                switch num {
                case 0:
                    self.thirdAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionA ?? ""
                case 1:
                    self.thirdAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionB ?? ""
                case 2:
                    self.thirdAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionC ?? ""
                case 3:
                    self.thirdAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionD ?? ""
                default:
                    print("")
                }
            }
            else {
                switch num {
                case 0:
                    self.FourthAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionA ?? ""
                case 1:
                    self.FourthAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionB ?? ""
                case 2:
                    self.FourthAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionC ?? ""
                case 3:
                    self.FourthAnswer = self.qnsAnsData?.data[self.currentQuestionIndex].optionD ?? ""
                default:
                    print("")
                }
            }
        }
        return cell
    }
        
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500.0
    }
    
}
