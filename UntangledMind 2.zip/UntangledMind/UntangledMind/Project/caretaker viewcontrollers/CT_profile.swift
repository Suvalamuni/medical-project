//
//  CT_profile.swift
//  hi
//
//  Created by k. Dharani on 12/12/23.
//

import UIKit

class CT_profile: UIViewController {
    @IBOutlet weak var relationship: UILabel!
    @IBOutlet weak var patient_name: UILabel!
    @IBOutlet weak var diagnosis: UILabel!
    @IBOutlet weak var ph_no: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var user_id: UILabel!
    
    var ct_details: CaretakerProfile?
    var userId: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        if let caretakerid = DoctorManager.shared.caretakerID {
                   print("caretaker ID: \(caretakerid)")
               } else {
                  print("caretaker ID is not available.")
               }
        getdetails()

       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getdetails()
        
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func logout(_ sender: Any) {
        UserDefaultsManager.shared.setPatinetLogin(bool: false)
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "SplashScreen")
        as! SplashScreen
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Edit(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
           let vc=storyBoard.instantiateViewController(identifier: "edit_ctprofile") as! edit_ctprofile
        vc.caretakerDetails = self.ct_details
           self.navigationController?.pushViewController(vc, animated: true)
       }
    func getdetails() {
        guard userId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) != nil else {
//            print("User ID is nil")
            return
        }
        let apiUrl = ServiceAPI.patient_profileUrl

        APIHandler().getAPIValues(type: CaretakerProfile.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let caretakerdetails):
                DispatchQueue.main.async {
                    self?.ct_details = caretakerdetails
                    if let userID = self?.ct_details?.data.first?.userID {
                        self?.user_id.text = String(userID)
                    }
                    if let name = self?.ct_details?.data.first?.name {
                        self?.name.text = String(name)
                    }

                    if let phone_no = self?.ct_details?.data.first?.phoneNo {
                        self?.ph_no.text = String(phone_no)
                    }

                    if let relation = self?.ct_details?.data.first?.relationship {
                        self?.relationship.text = String(relation)
                    }

                    if let patname = self?.ct_details?.data.first?.pName {
                        self?.patient_name.text = String(patname)
                    }

                    if let diag = self?.ct_details?.data.first?.diagnosis {
                        self?.diagnosis.text = String(diag)
                    }
                }
            case .failure(let error):
               print("API request failed with error: \(error)")
            }
        }
    }
}
    

