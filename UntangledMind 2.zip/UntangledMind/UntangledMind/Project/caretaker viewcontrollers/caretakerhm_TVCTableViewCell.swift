

import UIKit

class caretakerhm_TVCTableViewCell: UITableViewCell {
    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var suggestionlbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    
    override func layoutSubviews() {
         super.layoutSubviews()
         
     let margin = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
     contentView.frame = contentView.frame.inset(by: margin)
     contentView.layer.cornerRadius = 10
     }
}
