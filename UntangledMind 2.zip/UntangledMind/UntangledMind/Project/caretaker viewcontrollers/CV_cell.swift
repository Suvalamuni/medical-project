//
//  CV_cell.swift
//  UntangledMind
//
//  Created by k. Dharani on 28/01/24.
//

import UIKit

class CV_cell: UICollectionViewCell {
    
    @IBOutlet weak var motivationimg: UIImageView!
}
