
import UIKit

class caretakerlogin: UIViewController {

    @IBOutlet weak var onview: UIView!
    
    @IBOutlet weak var user_id: UITextField!
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginradius: UIButton!
    let loaderView = loader()
    
    var apiURL = String()
    var logInDetails: Caretaker_login_model!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        onview.layer.cornerRadius=5
        onview.clipsToBounds=true
        loginradius.layer.cornerRadius=5
        loginradius.clipsToBounds=true
        password.isSecureTextEntry = true
        
        onview.addSubview(loaderView)
                loaderView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    loaderView.centerXAnchor.constraint(equalTo: onview.centerXAnchor),
                    loaderView.centerYAnchor.constraint(equalTo: onview.centerYAnchor)
                ])
            
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func back(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: ViewController.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }

    }
    @IBAction func onlogin(_ sender: Any) {
        showLoader()
        if user_id.text == "" && password.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
            hideLoader()
        } else {
            getLoginAPI()
        }
    }

    func getLoginAPI() {
        apiURL = "\(ServiceAPI.CaretakerloginUrl)?user_id=\(user_id.text ?? "")&password=\(password.text ?? "")"
        
        let formData = [
            "user_id": user_id.text ?? "",
            "password": password.text ?? ""
        ]
        APIHandler().postAPIValues(type: Caretaker_login_model.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.logInDetails = data
                DispatchQueue.main.async {

                    if let firstDatum = self.logInDetails.data.first {
                        if self.user_id.text != firstDatum.userID && self.password.text != firstDatum.password {
                            let alert = UIAlertController(title: "OOPS", message: "Incorrect User ID & password", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                            })
                            self.present(alert, animated: true)
                        } else {
                            DoctorManager.shared.caretakerID = firstDatum.userID
                            UserDefaultsManager.shared.setPatinetLogin(bool: true)
                            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                            let vc = storyboard.instantiateViewController(withIdentifier: "homepage") as! homepage
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                    } else {
                        // Handle the case where logInDetails.data is empty
                        let alert = UIAlertController(title: "Alert", message: "Data is empty", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true)
                        
                    }
                    self.hideLoader()
                    }
            case .failure(let error):
//                print(error.localizedDescription)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    self.hideLoader()
                }
            }
        }
    }
    func showLoader() {
            loaderView.startAnimating()
        }
        
        func hideLoader() {
            loaderView.stopAnimating()
        }
}

