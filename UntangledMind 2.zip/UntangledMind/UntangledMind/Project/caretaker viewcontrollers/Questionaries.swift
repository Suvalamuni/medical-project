import UIKit

class Questionaries: UIViewController {
    
    @IBOutlet weak var ques: UITableView!
    
    var questions_list: GetQuestions?
    var answerOne = String()
    var answerTwo = String()
    var answerThree = String()
    var currentQuestionIndex: Int = 0
    var questionData: [GetSubQuestions] = [GetSubQuestions]()
    var selectedIndex : IndexPath = [0,0]
    var selectedOptions: [String?] = []
    var currentQuestion: GetSubQuestions?
    var selectedTag: Int = 0
    var finalData: [Any] = []
    var answerJson = ""
    var arrayOfDict: [[String: Any]] = []
    var jsonString: String = ""
    var getQnsAnsData: [GetSubQuestionsData] = [GetSubQuestionsData]()
    var responseDict: [String:Any] = [:]
    let loaderView = loader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        
        ques.allowsSelection = true
        ques.allowsMultipleSelection = true
        self.ques.delegate = self
        self.ques.dataSource = self
        arrayOfDict.removeAll()
        ques.register(UINib.init(nibName: "Questionariestc", bundle: nil), forCellReuseIdentifier: "Questionariestc")
        view.addSubview(loaderView)
                loaderView.isHidden = true
        getquestion()
    }
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated:true)
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func submit(_ sender: UIButton) {
   
        self.popUpAlert(title: "NOTICE", message: "Are you sure to Submit", actionTitles: ["OK","Cancel"], actionStyle:[.default,.default], action: [{ [weak self] Ok in
            guard let `self` = self else {return}
            sendAnswerAPI { success in
                if success {
                    DispatchQueue.main.async {
                        self.showQuestionDoneVC()
                    }
                }
            }
        }, { Cancel in
//            print("Submit Dismiss")
            self.dismiss(animated: true)
        }])
    }
    
    private func showQuestionDoneVC() {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "Ques_done")
        as! Ques_done
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func sendAnswerAPI(_ completionHandler:@escaping (Bool) -> Void) {

        let jsonString = convertArrayOfDictToJsonArray(array: arrayOfDict)
//        "user_id":
//        print(jsonString, "---->jsonString" ),ServiceAPI.caretakerUserId
        let parameter = ["userId" : DoctorManager.shared.caretakerID ?? "",
                         "Score" : jsonString] as [String : Any]
//        print("----parameter", parameter)
        APIHandler().postAPIRawJSON(type: PostAns.self, apiUrl: ServiceAPI.post_ans_Url, method: "POST", jsonData: parameter) { result in
            switch result {
            case .success(let data):
                completionHandler(true)
//                print("Answer Sucessfully send DB", data)
            case .failure(let error):
                completionHandler(false)
//                print(error)
            }
        }
    }
    
    func convertArrayOfDictToJsonArray(array: [[String: Any]]) -> [[String: Any]] {
        return array.map { dictionary in
            return [
                "Questionids": dictionary["Questionids"] ?? "",
                "Answer": dictionary["Answer"] ?? ""
            ]
        }
    }
    
    func getquestion() {
        loaderView.startAnimating()
        APIHandler().getAPIValues(type: GetQuestions.self, apiUrl: ServiceAPI.post_questionaries_Url, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
//                print("Received data from server: \(data)")
                DispatchQueue.main.async {
                    self?.loaderView.stopAnimating()
                    self?.questions_list = data
                    if let qnsSubData = data.data,  !qnsSubData.isEmpty  {
                        for qnsData in qnsSubData{
                            self?.getQnsAnsData.append(GetSubQuestionsData(questionID: qnsData.questionID, selectedAnsTag: nil, questionText: qnsData.questionText, options: qnsData.options))
                        }
                    }
//                    print(self?.getQnsAnsData,"getQnsAnsData")
                    self?.ques.reloadData() // GetSubQuestionsData
                }
            case .failure(let error):
                print("API Request Error: \(error)")
                DispatchQueue.main.async {
                    self?.loaderView.stopAnimating()
                }

            }
        }
    }
}

extension Questionaries: QuestionCellDelegate {
    func isQnsSelected(ansIndex: Int, qnsID: Int) {
        if let qnsIndex = self.getQnsAnsData.firstIndex(where: {$0 .questionID == qnsID}) {
//            print(qnsIndex,"qnsIndex")
            var isFound = false
            self.getQnsAnsData[qnsIndex].selectedAnsTag = ansIndex
            if arrayOfDict.count > 0 {
                for (index,resData) in arrayOfDict.enumerated() {
                    if let resQuestId = resData["Questionids"] as? Int, resQuestId == self.getQnsAnsData[qnsIndex].questionID, let answer = self.getQnsAnsData[qnsIndex].options?[ansIndex-1] {
                        isFound = true
                        arrayOfDict.remove(at: index)
                        responseDict["Questionids"] = self.getQnsAnsData[qnsIndex].questionID
                        responseDict["Answer"] = answer
                        arrayOfDict.append(responseDict)
                    }
                }
                if !isFound {
                    responseDict["Questionids"] = self.getQnsAnsData[qnsIndex].questionID
                    responseDict["Answer"] = self.getQnsAnsData[qnsIndex].options?[ansIndex-1]
                    arrayOfDict.append(responseDict)
                }
                
            } else {
                if let questionId = self.getQnsAnsData[qnsIndex].questionID, let answer = self.getQnsAnsData[qnsIndex].options?[ansIndex-1] {
                    responseDict["Questionids"] = questionId
                    responseDict["Answer"] = answer
                    arrayOfDict.append(responseDict)
                }
            }
            self.ques.reloadData()
        }
    }
}

extension Questionaries: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getQnsAnsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Questionariestc", for: indexPath) as! Questionariestc
        cell.tag = indexPath.row
        cell.delegate = self
        cell.questionCellConfig(configData: self.getQnsAnsData[indexPath.row])
        return cell
    }
}
