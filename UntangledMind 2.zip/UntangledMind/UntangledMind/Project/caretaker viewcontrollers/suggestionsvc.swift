//
//  suggestionsvc.swift
//  UntangledMind
//
//  Created by k. Dharani on 03/02/24.
//

import UIKit

class suggestionsvc: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var table: UITableView!
    var userId: String = ""
    var suggestions: GetSuggestions?
    let loaderView = loader()
    let noSuggestionsLabel = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "caretakerhm_TVCTableViewCell", bundle: nil), forCellReuseIdentifier: "caretakerhm_TVCTableViewCell")
        view.addSubview(loaderView)
                loaderView.frame = view.bounds
                loaderView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        setupNoSuggestionsLabel()
        //fetchData()
       
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
        fetchData()
    }
    @IBAction func onback(_ sender: Any) {
       navigationController?.popViewController(animated: true)
    }
    func setupNoSuggestionsLabel() {
           noSuggestionsLabel.text = "No suggestions found"
           noSuggestionsLabel.textColor = .black
           noSuggestionsLabel.textAlignment = .center
           noSuggestionsLabel.numberOfLines = 0
           noSuggestionsLabel.translatesAutoresizingMaskIntoConstraints = false
           view.addSubview(noSuggestionsLabel)
           
           NSLayoutConstraint.activate([
               noSuggestionsLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               noSuggestionsLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
           ])
           
           // Initially hide the label
           noSuggestionsLabel.isHidden = true
       }
       
    func fetchData() {
        loaderView.startAnimating()
        let apiUrl = "\(ServiceAPI.get_suggestionUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
        print(apiUrl)
        APIHandler().getAPIValues(type: GetSuggestions.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.suggestions = data
                    self?.table.reloadData()
                    self?.loaderView.stopAnimating()
                    self?.noSuggestionsLabel.isHidden = !(self?.suggestions?.data.isEmpty ?? true)

                }
            case .failure(let error):
                print("API Request Error: \(error)")
                DispatchQueue.main.async {
                    self?.loaderView.stopAnimating()
                    self?.noSuggestionsLabel.isHidden = false
                }
                    
            }
        }
    }
    
    @objc func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return suggestions?.data.count ?? 0
    }
    
    @objc(tableView:cellForRowAtIndexPath:) func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "caretakerhm_TVCTableViewCell", for: indexPath) as! caretakerhm_TVCTableViewCell
        
        let suggestionslist = suggestions?.data[indexPath.row]
        cell.datelbl.text = suggestionslist?.date
        cell.suggestionlbl.text = suggestionslist?.suggestion
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
