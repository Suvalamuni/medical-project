//
//  test_tvc.swift
//  hi
//
//  Created by k. Dharani on 04/01/24.
//

import UIKit

class test_tvc: UITableViewCell {

    @IBOutlet weak var ques_id: UILabel!
    @IBOutlet weak var questiontext: UILabel!
    @IBOutlet weak var op1: UILabel!
    @IBOutlet weak var op2: UILabel!
    @IBOutlet weak var op3: UILabel!
    @IBOutlet weak var op4: UILabel!
    @IBOutlet weak var opt1: UIButton!
    @IBOutlet weak var opt2: UIButton!
    @IBOutlet weak var opt3: UIButton!
    @IBOutlet weak var opt4: UIButton!
    
    
    var selectNum:((Int) ->())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    @IBAction func Copt1(_ sender: Any) {
        
        selectNum?(0)
            if opt1.imageView?.image == UIImage(named: "selectedBox") {
                
               
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                




            }else {
                opt1.setImage(UIImage(named:"selectedBox"), for: .normal)
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                
            }
            
        }
        @IBAction func Copt2(_ sender: Any) {
            selectNum?(1)
            if opt2.imageView?.image == UIImage(named: "selectedBox") {
                
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)
                
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                
            }else {
                opt2.setImage(UIImage(named:"selectedBox"), for: .normal)
                
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                
                
            }
        }
        @IBAction func Copt3(_ sender: Any) {
            selectNum?(2)
            if opt3.imageView?.image == UIImage(named: "selectedBox") {
                
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                
                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                

            }else {
                opt3.setImage(UIImage(named:"selectedBox"), for: .normal)
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)

                opt4.setImage(UIImage(named:"unSelect"), for: .normal)
                
            }
        }
        @IBAction func Copt4(_ sender: Any) {
            selectNum?(3)
            if opt4.imageView?.image == UIImage(named: "selectedBox") {
               
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                
                

            }else {
                
                opt4.setImage(UIImage(named:"selectedBox"), for: .normal)
                opt1.setImage(UIImage(named:"unSelect"), for: .normal)
                opt2.setImage(UIImage(named:"unSelect"), for: .normal)
                opt3.setImage(UIImage(named:"unSelect"), for: .normal)
                
            }
        }
       
}
