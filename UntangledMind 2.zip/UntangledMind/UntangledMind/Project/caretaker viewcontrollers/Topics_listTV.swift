//
//  Topics_listTV.swift
//  hi
//
//  Created by k. Dharani on 21/11/23.
//

import UIKit

class Topics_listTV: UITableViewCell {

    @IBOutlet weak var topicname: UILabel!
    
    @IBOutlet weak var topicid: UILabel!
    @IBOutlet weak var imagelist: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
