import UIKit

class Topics_list: UIViewController, UITableViewDelegate, UITableViewDataSource {
 
    @IBOutlet weak var TABLE: UITableView!
    var topiclist: Topics?

    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//        self.view.addGestureRecognizer(tapGesture)
        TABLE.delegate = self
        TABLE.dataSource = self
        TABLE.register(UINib(nibName: "Topics_listTV", bundle: nil), forCellReuseIdentifier: "Topics_listTV")
        fetchData()
    }


    func fetchData() {
        APIHandler().getAPIValues(type: Topics.self, apiUrl: ServiceAPI.topic_listUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.topiclist = data
                    self?.TABLE.reloadData() 
                }
            case .failure(let error):
                print("API Request Error: \(error)")
            }
        }
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topiclist?.data.count ?? 0
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(identifier: "psycho_education") as! psycho_education
        if let selectedTopic = topiclist?.data[indexPath.row] {
                vc.selectedTopicName = selectedTopic.topicName
            }
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }

    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Topics_listTV", for: indexPath) as! Topics_listTV

        if let topic = topiclist?.data[indexPath.row] {
            cell.topicname.text = topic.topicName
            cell.topicid.text = topic.topicID
        }

        return cell
    }

}
