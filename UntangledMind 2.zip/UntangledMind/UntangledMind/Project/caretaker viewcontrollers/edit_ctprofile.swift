import UIKit

class edit_ctprofile: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var relationship: UITextField!
    @IBOutlet weak var patient_name: UITextField!
    @IBOutlet weak var diagnosis: UITextField!
    @IBOutlet weak var ph_no: UITextField!
    @IBOutlet weak var ctname: UITextField!
    
    @IBOutlet weak var user_id: UILabel!
    var userId: String = ""
    var caretakerDetails: CaretakerProfile?
    let loaderView = loader()

    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        ph_no.delegate = self

        if let userID = self.caretakerDetails?.data.first?.userID {
            user_id.text = String(userID)
        }
        if let name = self.caretakerDetails?.data.first?.name {
            ctname.text = name
        }
        if let phno = self.caretakerDetails?.data.first?.phoneNo {
            ph_no.text = phno
        }
        if let relation = self.caretakerDetails?.data.first?.relationship {
            relationship.text = relation
        }
        if let patname = self.caretakerDetails?.data.first?.pName {
            patient_name.text = patname
        }
        
        if let diag = self.caretakerDetails?.data.first?.diagnosis {
            diagnosis.text = diag
        }
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func displayCaretakerDetails(){
        guard let Caretaker = self.caretakerDetails?.data.first else {
            return
            
        }
        user_id.text = String(Caretaker.userID)
        ctname.text = Caretaker.name
        ph_no.text = Caretaker.phoneNo
        relationship.text = Caretaker.relationship
        patient_name.text = Caretaker.pName
        diagnosis.text = Caretaker.diagnosis
        
    }
    @IBAction func back(_ sender: Any) {

        navigationController?.popViewController(animated: true)
        
    }
    @IBAction func save(_ sender: Any) {
    
   
    
    guard let phoneNumber = ph_no.text, !phoneNumber.isEmpty else {
        displayAlert(message: "Please enter a phone number.")
        return
    }
    
    guard validatePhoneNumber(phoneNumber) else {
        displayAlert(message: "Please enter a 10-digit phone number.")
        return
    }
    
    saveAPI()
        showLoader()
        
}
    

func displayAlert(message: String) {
    let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
    let okAction = UIAlertAction(title: "OK", style: .default)
    alert.addAction(okAction)
    present(alert, animated: true, completion: nil)
}
        func validateEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.com"
            let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
            return emailPredicate.evaluate(with: email)
        }


    func validatePhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneRegex = "^\\d{10}$"
        let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: phoneNumber)
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if textField == ph_no {
                // Check if the new string contains only digits
                let allowedCharacters = CharacterSet.decimalDigits
                let characterSet = CharacterSet(charactersIn: string)
                if !allowedCharacters.isSuperset(of: characterSet) && !string.isEmpty {
                    displayAlert(message: "Please enter digits only for phone number.")
                    return false
                }
                
               
                let currentText = textField.text ?? ""
                guard let stringRange = Range(range, in: currentText) else { return false }
                let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
                if updatedText.count > 10 {
                    displayAlert(message: "Phone number should be 10 digits long.")
                    return false
                }
            }
            return true
        }

   
    func saveAPI() {
        guard let doctor = self.caretakerDetails?.data.first else {
            return
        }
        let formData: [String: String] = [
            "user_id": user_id.text ?? "",
            "Name": ctname.text ?? "",
            "phone_no": ph_no.text ?? "",
            "Relationship": relationship.text ?? "",
            "p_Name": patient_name.text ?? "",
            "Diagnosis": diagnosis.text ?? "",
        ]
        
        print(formData, ServiceAPI.edit_ctdetailsUrl)
        
        APIHandler().postAPIValues(type: EditCtprof.self, apiUrl: ServiceAPI.edit_ctdetailsUrl, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data.message)
               
              
                DispatchQueue.main.async {
                    if let vc = self?.navigationController?.viewControllers.first as? CT_profile {
                        vc.ct_details = self?.caretakerDetails
                        vc.getdetails() // Reload data
                        self?.hideLoader()
                    }
                    self?.navigationController?.popViewController(animated: true)
                }
            case.failure(let error):
                print("Network Error: \(error)")
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive))
                    self?.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func showLoader() {
            loaderView.frame = view.bounds
            view.addSubview(loaderView)
            loaderView.startAnimating()
        }
        
        func hideLoader() {
            DispatchQueue.main.async {
                self.loaderView.stopAnimating()
                self.loaderView.removeFromSuperview()
            }
        }

}

    

