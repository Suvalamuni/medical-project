//
//  homepage.swift
//  hi
//
//  Created by k. Dharani on 28/09/23.
//

import UIKit

class homepage: UIViewController {
    
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var onview: UIButton!
    var ctname: Caretakernamemodel?
    
    @IBOutlet weak var proflieview: UIView!
    

    @IBOutlet weak var proflie: UIButton!
    override func viewDidLoad() {
        getdetails()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        onview.layer.cornerRadius=5
        onview.clipsToBounds=true
        super.viewDidLoad()
        
//       // proflieview.layer.cornerRadius=40
//        proflieview.layer.maskedCorners=[.layerMinXMaxYCorner]
//        self.navigationController?.isNavigationBarHidden = true
        
        
    }
   
    func getdetails() {
       

        let apiUrl = "\(ServiceAPI.caretaker_nameUrl)?user_id=\(DoctorManager.shared.caretakerID ?? "0")"
        print(apiUrl)

        APIHandler().getAPIValues(type: Caretakernamemodel.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
            switch result {
            case .success(let doctName):
                DispatchQueue.main.async {
                    self?.ctname = doctName
                    self?.namelbl.text = doctName.data.first?.name
                    
                }
            case .failure(let error):
                print("API request failed with error: \(error)")
            }
        }
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    @IBAction func onprofile(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "CT_profile")
        as! CT_profile
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func next(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "Questionaries")
        as! Questionaries
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func skip(_ sender: Any) {
        let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc=storyBoard.instantiateViewController(identifier: "Caretaker_hm")
        as! Caretaker_hm
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
