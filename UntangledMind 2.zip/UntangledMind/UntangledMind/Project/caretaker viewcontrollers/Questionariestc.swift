//
//  Questionariestc.swift
//  hi
//
//  Created by k. Dharani on 16/11/23.
//

import UIKit

protocol QuestionCellDelegate {
    func isQnsSelected(ansIndex: Int, qnsID: Int)
}
class Questionariestc: UITableViewCell {
    @IBOutlet weak var Ques_id: UILabel!
    @IBOutlet weak var question: UILabel!
    @IBOutlet weak var opt1: UIButton!
    @IBOutlet weak var opt2: UIButton!
    @IBOutlet weak var opt3: UIButton!
    @IBOutlet weak var opt4: UIButton!
    @IBOutlet weak var opt5: UIButton!
    @IBOutlet weak var op1: UILabel!
    @IBOutlet weak var op2: UILabel!
    @IBOutlet weak var op3: UILabel!
    @IBOutlet weak var op4: UILabel!
    @IBOutlet weak var op5: UILabel!
    
    var delegate : QuestionCellDelegate!
    var QnsID : Int?
    
    
    var selectedButton: UIButton?
    var indexPath: IndexPath?
    var butto1TapHandler: ((_ senderTag:Int) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.frame.inset(by: margin)
        contentView.layer.cornerRadius = 5
    }
    
    func questionCellConfig(configData : GetSubQuestionsData) {
        self.Ques_id.text = String(configData.questionID ?? 0)
        QnsID = configData.questionID
        
        self.question.text = configData.questionText
        self.op1.text = configData.options?[0]
        self.op2.text = configData.options?[1]
        self.op3.text = configData.options?[2]
        self.op4.text = configData.options?[3]
        self.op5.text = configData.options?[4]
        
        opt1.setImage(UIImage(named: "unSelect"), for: .normal)
        opt2.setImage(UIImage(named: "unSelect"), for: .normal)
        opt3.setImage(UIImage(named: "unSelect"), for: .normal)
        opt4.setImage(UIImage(named: "unSelect"), for: .normal)
        opt5.setImage(UIImage(named: "unSelect"), for: .normal)

        if let b = configData.selectedAnsTag {
            
            if b == 1 {
                opt1.setImage(UIImage(named: "selectedBox"), for: .normal)
            } else if b == 2 {
                opt2.setImage(UIImage(named: "selectedBox"), for: .normal)
            }else if b == 3 {
                opt3.setImage(UIImage(named: "selectedBox"), for: .normal)
            }else if b == 4 {
                opt4.setImage(UIImage(named: "selectedBox"), for: .normal)
            }else if b == 5 {
                opt5.setImage(UIImage(named: "selectedBox"), for: .normal)
            }
        }
    }
    @IBAction func optionButtonTapped(_ sender: UIButton) {
        if let qnsId = self.QnsID {
            delegate.isQnsSelected(ansIndex: sender.tag, qnsID: qnsId)
        }
    }
}
