//
//  psycho_education.swift
//  hi
//
//  Created by k. Dharani on 31/10/23.
//

import UIKit

class psycho_education: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var topicname: UILabel!
    @IBOutlet weak var table: UITableView!
    var subtopiclist: Subtopics?
    var selectedTopicName: String?
    override func viewDidLoad() {
        super.viewDidLoad()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//                self.view.addGestureRecognizer(tapGesture)
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "subtopic_tvc", bundle: nil), forCellReuseIdentifier: "subtopic_tvc")
        if let selectedTopic = selectedTopicName {
            topicname.text = selectedTopic
        }
       // fetchData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
        fetchData()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func fetchData() {
        
        APIHandler().getAPIValues(type: Subtopics.self, apiUrl:ServiceAPI.getsubtopicUrl+"?topic_name=\(selectedTopicName ?? "")" , method: "GET") { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self?.subtopiclist = data
                    self?.table.reloadData()
                }
            case .failure(let error):
                print("API Request Error: \(error)")
            }
        }
    }
        
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return subtopiclist?.data.count ?? 0
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(identifier: "BPA") as! BPA
            vc.selectedSubTopic = subtopiclist?.data[indexPath.row].subtopicName ?? ""
            self.navigationController?.pushViewController(vc, animated: true)
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "subtopic_tvc", for: indexPath) as! subtopic_tvc
            
            if let subtopic = subtopiclist?.data[indexPath.row] {
                cell.sb_name.text = subtopic.subtopicName
                cell.subtopic_id.text = subtopic.subtopicId
            }
            
            return cell
        }
        
        @IBAction func back(_ sender: Any) {
            self.navigationController?.popViewController(animated:true)
        }
        
        
    }

