//
//  dcotorlisttvc.swift
//  UntangledMind
//
//  Created by Amar on 19/03/24.
//

import UIKit

class dcotorlisttvc: UITableViewCell {

    @IBOutlet weak var docimageLabel: UIImageView!
    @IBOutlet weak var useridLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    var task: URLSessionDataTask?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func prepareForReuse() {
            super.prepareForReuse()
            // Cancel the download task when cell is reused
            task?.cancel()
        docimageLabel.image = nil // Reset image to avoid flickering
        }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
