import Foundation
import UIKit

class Utlis {
    static func showAlert(title:String, message:String, view: UIViewController) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        view.present(alert, animated: true)
//
    }
    
    static func showAlertWithCompletion(message: String ,view: UIViewController,_ completion: @escaping () -> Void) {
        let alertController = UIAlertController(title: "Title", message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            // Call the completion handler when OK is pressed
            completion()
        }
        alertController.addAction(okAction)
        // Present the alert
            view.present(alertController, animated: true)
    }
}
