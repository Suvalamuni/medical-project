//import UIKit
//
//class DoctorManager {
//    static let shared = DoctorManager()
//
//    var doctorID: String?
//    var caretakerID: String?
//
//
//    private init() {}
//    
//    
//    
//    func sendMessage(title:String,message:String,navigation:UINavigationController) {
//            
//           
//            let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
//            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
//            alertController.addAction(cancelAction)
//            navigation.present(alertController, animated: false, completion: nil)
//        }
//}
import UIKit

class DoctorManager {
    static let shared = DoctorManager()

    // UserDefaults keys
    private let doctorIDKey = "DoctorID"
    private let caretakerIDKey = "CaretakerID"
    private let AdminIdKey = "AdminID"
    
    
    
  
    
    

    var doctorID: String? {
        get {
            return UserDefaults.standard.string(forKey: doctorIDKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: doctorIDKey)
        }
    }
    var adminID: String? {
        get {
            return UserDefaults.standard.string(forKey: AdminIdKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: AdminIdKey)
        }
    }

    var caretakerID: String? {
        get {
            return UserDefaults.standard.string(forKey: caretakerIDKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: caretakerIDKey)
        }
    }

    private init() {}

    func isLoggedIn() -> Bool {
        // Check if any user is logged in
        return doctorID != nil || caretakerID != nil || adminID != nil
    }

    func logout() {
        // Clear saved user information
        UserDefaults.standard.removeObject(forKey: doctorIDKey)
        UserDefaults.standard.removeObject(forKey: caretakerIDKey)
        UserDefaults.standard.removeObject(forKey: AdminIdKey)
    }

    func sendMessage(title: String, message: String, navigation: UINavigationController) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        navigation.present(alertController, animated: false, completion: nil)
    }
}
