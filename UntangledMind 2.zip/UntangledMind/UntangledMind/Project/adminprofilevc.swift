//
//  adminprofilevc.swift
//  UntangledMind
//
//  Created by apple on 27/03/24.
//

import UIKit

class adminprofilevc: UIViewController {

    

        @IBOutlet weak var user_id: UILabel!
        @IBOutlet weak var Name: UILabel!
        @IBOutlet weak var email_id: UILabel!
        @IBOutlet weak var phone_no: UILabel!
        @IBOutlet weak var designation: UILabel!
        @IBOutlet weak var institution: UILabel!
        
        var admin_details: adminprofile?
        var userId: String = ""
        let loaderView = loader()


        override func viewDidLoad() {
            super.viewDidLoad()
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                    self.view.addGestureRecognizer(tapGesture)
           
        }
       

        override func viewWillAppear(_ animated: Bool) {
                super.viewWillAppear(animated)
            if let adminID = DoctorManager.shared.adminID {
                       print("Doctor ID: \(adminID)")
                   } else {
                       print("Doctor ID is not available.")
                   }
                getdetails()
            }
        @IBAction func onback(_ sender: Any) {
            navigationController?.popViewController(animated: true)
        }
        @objc func dismissKeyboard() {
                view.endEditing(true)
            }
        @IBAction func onlogout(_ sender: Any) {
           // UserDefaultsManager.shared.setLogin(bool: false)
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc=storyBoard.instantiateViewController(identifier: "SplashScreen")
                as! SplashScreen
            self.navigationController?.pushViewController(vc, animated: true)
        }

        @IBAction func Edit(_ sender: Any) {
            let storyBoard:UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
               let vc=storyBoard.instantiateViewController(identifier: "admineditprofilevc") as! admineditprofilevc
            vc.adminDetails = self.admin_details
               self.navigationController?.pushViewController(vc, animated: true)
           }
        func getdetails() {
    //        showLoader()
            guard userId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) != nil else {
                print("User ID is nil")
                return
            }
            let apiUrl = ServiceAPI.adminprofileUrl

            APIHandler().getAPIValues(type: adminprofile.self, apiUrl: apiUrl, method: "GET") { [weak self] result in
                switch result {
                case .success(let admindetails):
                    DispatchQueue.main.async {
                        self?.admin_details = admindetails
                        if let userID = self?.admin_details?.data.first?.userID {
                            self?.user_id.text = String(userID)
                        }
                        if let name = self?.admin_details?.data.first?.name {
                            self?.Name.text = String(name)
                        }

                        if let email = self?.admin_details?.data.first?.emailID {
                            self?.email_id.text = String(email)
                        }

                        if let phone = self?.admin_details?.data.first?.phoneNo {
                            UserDefaults.standard.setValue(phone, forKey: "DoctorPhone")
                            self?.phone_no.text = String(phone)
                            
                        }

                        if let institution = self?.admin_details?.data.first?.institution {
                            self?.institution.text = String(institution)
                        }

                        if let designation = self?.admin_details?.data.first?.designation {
                            self?.designation.text = String(designation)
    //                        self?.hideLoader()

                        }
                    }
                case .failure(let error):
                    print("API request failed with error: \(error)")
    //                self?.hideLoader()
                }
            }
        }
    //    func showLoader() {
    //            loaderView.frame = view.bounds
    //            view.addSubview(loaderView)
    //            loaderView.startAnimating()
    //        }
    //
    //        // Method to hide the loader
    //        func hideLoader() {
    //            loaderView.stopAnimating()
    //            loaderView.removeFromSuperview()
    //        }
    }


