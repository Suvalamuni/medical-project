//
//  caretakerslistvc.swift
//  UntangledMind
//
//  Created by apple on 23/03/24.
//

import UIKit

class caretakerslistvc: UIViewController,UISearchBarDelegate,UISearchTextFieldDelegate  {
    @IBOutlet weak var listTable: UITableView!
    var caretakerslist: ct_list?
    var Searchbar:SearchbarModel?
    var searchOption = false
    var doctorid: String = ""
    var docname: DoctorName?
    let refreshControl = UIRefreshControl()
    let loaderView = loader()
    @IBOutlet weak var searchbar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        listTable.dataSource = self
        listTable.delegate = self
        listTable.register(UINib(nibName: "CrackerListCell", bundle: nil), forCellReuseIdentifier: "CrackerListCell")
        searchbar.delegate = self
        view.addSubview(loaderView)
                loaderView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    loaderView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                    loaderView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
                ])

        
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        listTable.addSubview(refreshControl)
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
        fetchData()
    }
    @objc func refresh(_ sender: AnyObject) {
       // Code to refresh table view
        searchOption = false
        fetchData()
    }
    func searchApi(userId: String) {
        let formData = [
            "user_id": userId,
            "search" : userId
        ]

        searchOption = true
        //http://192.168.210.118/medproject/search.php?search=M
        let url = "\(ServiceAPI.searchBarUrl)?search=\(userId)"
        APIHandler.shared.getAPIValues(type: SearchbarModel.self, apiUrl: url, method: "GET") { [weak self] result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
//                        self?.Searchbar = UntangledMind.Searchbar(status: true, search: response)
                        self?.Searchbar = response
                        self?.listTable.reloadData()
                        print("Search API Success:", response)
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert", message: "The Patient Does not Exist", preferredStyle: .alert)
                        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(cancelAction)
                        self?.present(alertController, animated: false, completion: nil)
                        print("Search API Error:", error)
                    }
                }
            }
        }

    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func fetchData() {
        showLoader()
        APIHandler().getAPIValues(type: ct_list.self, apiUrl: ServiceAPI.Caretakers_listUrl, method: "GET") { [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        // Reverse the order of the data array
                        self?.caretakerslist = ct_list(status: data.status, data: data.data?.reversed())

                        self?.listTable.reloadData()
                        self?.refreshControl.endRefreshing()
                        self?.hideLoader()
                    }
                case .failure(let error):
                    print("API Request Error: \(error)")
                    self?.hideLoader()
                    // Handle the failure case as needed
                }
            }
        }
    func showLoader() {
           loaderView.startAnimating()
       }
       
       func hideLoader() {
           loaderView.stopAnimating()
       }
   
}
extension caretakerslistvc: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchOption {
       
            return Searchbar?.data.count ?? 0
        } else {
            return caretakerslist?.data?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CrackerListCell", for: indexPath) as! CrackerListCell
        if searchOption {

            cell.Name.text = Searchbar?.data[indexPath.row].name
            cell.user_id.text = Searchbar?.data[indexPath.row].userID
            cell.Diagnosis.text = Searchbar?.data[indexPath.row].diagnosis

            if let imgurlStr = Searchbar?.data[indexPath.row].caretakerImage,
                           let imgUrl = URL(string: ServiceAPI.baseUrl + imgurlStr) {
                            DispatchQueue.global().async {
                                URLSession.shared.dataTask(with: imgUrl) { (data, response, error) in
                                    guard let data = data, error == nil else {
                                        print("Failed to download image:", error?.localizedDescription ?? "Unknown error")
                                        DispatchQueue.main.async {
                                            cell.Profile_Image.image = UIImage(named: "Rectangle 9")
                                        }
                                        return
                                    }

                                    DispatchQueue.main.async {
                                        cell.Profile_Image.image = UIImage(data: data)
                                    }
                                }.resume()
                            }
                        }
        } else {
            if let caretakerslist = caretakerslist, let dict = caretakerslist.data?[indexPath.row] {
                cell.Name.text = dict.name
                cell.Diagnosis.text = dict.diagnosis
                cell.user_id.text = caretakerslist.data?[indexPath.row].userID
                UserDefaults.standard.setValue(caretakerslist.data?[indexPath.row].userID, forKey: "SelecteduserID")

                if let imgurlStr = dict.caretakerImage,
                   let imgUrl = URL(string: ServiceAPI.baseUrl + imgurlStr) {
                    DispatchQueue.global().async {
                        URLSession.shared.dataTask(with: imgUrl) { (data, response, error) in
                            guard let data = data, error == nil else {
                                // Handle the error, if any
                                print("Failed to download image:", error?.localizedDescription ?? "Unknown error")
                                DispatchQueue.main.async {
                                    cell.Profile_Image.image = UIImage(named: "Rectangle 9")
                                }
                                return
                            }
                            
                            DispatchQueue.main.async {
                                // Update the UI on the main thread
                                cell.Profile_Image.image = UIImage(data: data)
                            }
                        }.resume()
                    }
                }


            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "CaretakerInfoViewController") as! CaretakerInfoViewController

            if searchOption {
                if let id = Searchbar?.data[indexPath.row].userID {
                    DoctorManager.shared.caretakerID = id
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                if let ids = caretakerslist?.data?[indexPath.row].userID {
                    DoctorManager.shared.caretakerID = ids
                    print("Selected patient ID-->", ids)
                    print(DoctorManager.shared.caretakerID!)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }

 
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
}

extension caretakerslistvc: UITextFieldDelegate {


    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            
            searchOption = false
            listTable.reloadData()
        } else {
            // Perform search
            searchApi(userId: searchText)
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("Return key pressed")
        textField.resignFirstResponder()
        return true
    }
}

