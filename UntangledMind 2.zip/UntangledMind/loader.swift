//
//  loader.swift
//  UntangledMind
//
//  Created by k. Dharani on 20/02/24.
//

import UIKit

class loader: UIView {
   
        private let activityIndicatorView: UIActivityIndicatorView = {
            let activityIndicatorView = UIActivityIndicatorView(style: .large)
            activityIndicatorView.color = .gray
            activityIndicatorView.translatesAutoresizingMaskIntoConstraints = false
            return activityIndicatorView
        }()

        override init(frame: CGRect) {
            super.init(frame: frame)
            setupUI()
        }

        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            setupUI()
        }

        private func setupUI() {
            addSubview(activityIndicatorView)
            NSLayoutConstraint.activate([
                activityIndicatorView.centerXAnchor.constraint(equalTo: centerXAnchor),
                activityIndicatorView.centerYAnchor.constraint(equalTo: centerYAnchor)
            ])
        }

        func startAnimating() {
            activityIndicatorView.startAnimating()
            isHidden = false
        }

    func stopAnimating() {
        DispatchQueue.main.async { [weak self] in
            self?.activityIndicatorView.stopAnimating()
            self?.isHidden = true
        }
    }

    }


