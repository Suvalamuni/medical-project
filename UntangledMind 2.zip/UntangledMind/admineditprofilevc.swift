//
//  admineditprofilevc.swift
//  UntangledMind
//
//  Created by apple on 27/03/24.
//

import UIKit

class admineditprofilevc: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var user_id: UILabel!
    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var email_id: UITextField!
    @IBOutlet weak var phone_no: UITextField!
    @IBOutlet weak var institution1: UITextField!
    @IBOutlet weak var designation: UITextField!
    @IBOutlet weak var password: UITextField!
    
    var adminDetails: adminprofile?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        displayDoctorDetails()
        phone_no.delegate = self
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    func displayDoctorDetails() {
        guard let admin = self.adminDetails?.data.first else {
            return
        }
        
        user_id.text = String(admin.userID)
        Name.text = admin.name
        email_id.text = admin.emailID
        phone_no.text = admin.phoneNo
        institution1.text = admin.institution
        designation.text = admin.designation
    }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func save(_ sender: Any) {guard let email = email_id.text, !email.isEmpty else {
        displayAlert(message: "Please enter an email address.")
        return
    }
    
    guard validateEmail(email) else {
        displayAlert(message: "Please enter a valid email address.")
        return
    }
    
    guard let phoneNumber = phone_no.text, !phoneNumber.isEmpty else {
        displayAlert(message: "Please enter a phone number.")
        return
    }
    
    guard validatePhoneNumber(phoneNumber) else {
        displayAlert(message: "Please enter a 10-digit phone number.")
        return
    }
    
    saveAPI()
}
    

func displayAlert(message: String) {
    let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
    let okAction = UIAlertAction(title: "OK", style: .default)
    alert.addAction(okAction)
    present(alert, animated: true, completion: nil)
}
        func validateEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.com"
            let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
            return emailPredicate.evaluate(with: email)
        }


    func validatePhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneRegex = "^\\d{10}$"
        let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: phoneNumber)
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if textField == phone_no {
                // Check if the new string contains only digits
                let allowedCharacters = CharacterSet.decimalDigits
                let characterSet = CharacterSet(charactersIn: string)
                if !allowedCharacters.isSuperset(of: characterSet) && !string.isEmpty {
                    displayAlert(message: "Please enter digits only for phone number.")
                    return false
                }
                
                // Limit the length of the phone number to 10 digits
                let currentText = textField.text ?? ""
                guard let stringRange = Range(range, in: currentText) else { return false }
                let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
                if updatedText.count > 10 {
                    displayAlert(message: "Phone number should be 10 digits long.")
                    return false
                }
            }
            return true
        }
    func saveAPI() {
        guard let admin = self.adminDetails?.data.first else {
            return
        }
        
        let formData: [String: String] = [
            "user_id": String(admin.userID),
            "Name": Name.text ?? "",
            "password": password.text ?? "",
            "phone_no": phone_no.text ?? "",
            "email_id": email_id.text ?? "",
            "institution": institution1.text ?? "",
            "designation": designation.text ?? "",
        ]
        
        APIHandler().postAPIValues(type: editadprof.self, apiUrl: ServiceAPI.editaminprofileUrl, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data.message)
                DispatchQueue.main.async {
                    // Update the details on the previous page
                    if let vc = self?.navigationController?.viewControllers.first as? adminprofilevc {
                        vc.admin_details = self?.adminDetails
                        vc.getdetails() // Reload data
                    }
                    self?.navigationController?.popViewController(animated: true)
                }
            case .failure(let error):
                print("Network Error: \(error)")
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive))
                    self?.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    

}
