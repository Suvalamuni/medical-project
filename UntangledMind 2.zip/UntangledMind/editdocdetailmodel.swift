

import Foundation

// MARK: - Editdocdetail
struct Editdocdetail: Codable {
    let status: Bool
    let message: String
}
